from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from app.company_detection import group_documents, normalize_company_key


def _simple_pdf(path: Path, company: str | None) -> None:
    pdf = canvas.Canvas(str(path), pagesize=A4)
    if company:
        pdf.setFont("Helvetica-Bold", 18)
        pdf.drawString(72, 760, company)
    pdf.setFont("Helvetica", 11)
    pdf.drawString(72, 730, "Annual Report 2025")
    pdf.drawString(72, 700, "Consolidated financial statements")
    pdf.save()


def test_legal_suffixes_normalize_to_same_company():
    assert normalize_company_key("Tata Consultancy Services Limited") == normalize_company_key("Tata Consultancy Services Ltd.")


def test_mixed_companies_are_split_and_matching_reports_are_grouped(tmp_path: Path):
    tcs_2024 = tmp_path / "tcs_2024.pdf"
    tcs_2025 = tmp_path / "tcs_2025.pdf"
    tata_capital = tmp_path / "tata_capital_2025.pdf"
    _simple_pdf(tcs_2024, "Tata Consultancy Services Limited")
    _simple_pdf(tcs_2025, "Tata Consultancy Services Ltd.")
    _simple_pdf(tata_capital, "Tata Capital Limited")

    groups = group_documents([tcs_2024, tcs_2025, tata_capital])
    assert len(groups) == 2
    sizes = sorted(len(group.documents) for group in groups)
    assert sizes == [1, 2]
    assert any("consultancy" in group.company_key for group in groups)
    assert any(group.company_key == "tata capital" for group in groups)


def test_uncertain_files_are_not_silently_merged(tmp_path: Path):
    first = tmp_path / "annual_report_2024.pdf"
    second = tmp_path / "annual_report_2025.pdf"
    _simple_pdf(first, None)
    _simple_pdf(second, None)

    groups = group_documents([first, second])
    assert len(groups) == 2
    assert all(group.review_required for group in groups)


def test_pdf_inspection_reuses_candidate_statement_pages(tmp_path: Path):
    report = tmp_path / "sample_2025.pdf"
    pdf = canvas.Canvas(str(report), pagesize=A4)
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawString(72, 760, "Example Industries Limited")
    pdf.drawString(72, 720, "Annual Report 2025")
    pdf.showPage()
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(72, 760, "CONSOLIDATED BALANCE SHEET")
    pdf.drawString(72, 720, "Particulars 31 March 2025 31 March 2024")
    pdf.save()

    groups = group_documents([report])
    document = groups[0].documents[0]
    assert document.page_count == 2
    assert 2 in document.candidate_pages
    assert document.extraction_hint()["candidate_pages"]
