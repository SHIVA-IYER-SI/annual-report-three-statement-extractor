from app.core.resources import line_item_universes, validation_universes, verify_runtime_resources


def test_blueprint_resources_are_unchanged_and_complete():
    assert verify_runtime_resources() == []
    universes = line_item_universes()
    checks = validation_universes()
    assert len(universes["INCOME_STATEMENT"]) == 159
    assert len(universes["BALANCE_SHEET"]) == 193
    assert len(universes["CASH_FLOW_STATEMENT"]) == 85
    assert len(checks["INCOME_STATEMENT"]) == 16
    assert len(checks["BALANCE_SHEET"]) == 27
    assert len(checks["CASH_FLOW_STATEMENT"]) == 15
