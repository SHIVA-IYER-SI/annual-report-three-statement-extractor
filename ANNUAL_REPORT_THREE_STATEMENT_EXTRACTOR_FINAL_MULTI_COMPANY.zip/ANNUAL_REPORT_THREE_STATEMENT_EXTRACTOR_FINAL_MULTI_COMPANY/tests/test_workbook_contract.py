from pathlib import Path
from app.core.workbook import SHEET_ORDER, assert_workbook_contract, build_workbook


def test_exact_workbook_contract(tmp_path: Path):
    payload = {
        "company_name": "Example Limited",
        "scope": "consolidated",
        "currency_unit": "INR_crore",
        "years": ["FY24", "FY25"],
        "statements": {
            sheet: [
                {
                    "key": f"{sheet}.revenue",
                    "label": "Revenue from operations",
                    "row_type": "major_total",
                    "value_type": "currency",
                    "hierarchy_level": 0,
                    "include": True,
                    "has_included_children": True,
                    "values": {"FY24": "100", "FY25": "120"},
                    "formulas": {},
                    "sources": {},
                    "statuses": {},
                }
            ]
            for sheet in SHEET_ORDER
        },
    }
    path = tmp_path / "model.xlsx"
    build_workbook(payload).save(path)
    assert assert_workbook_contract(path) == []
