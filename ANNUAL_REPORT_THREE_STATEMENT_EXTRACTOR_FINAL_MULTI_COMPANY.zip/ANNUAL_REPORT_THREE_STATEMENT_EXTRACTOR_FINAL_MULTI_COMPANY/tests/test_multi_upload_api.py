from fastapi.testclient import TestClient

from app.main import app


def test_file_count_limits_and_sequential_upload():
    client = TestClient(app)

    too_many = client.post(
        "/api/jobs/init",
        data={
            "company_name": "Example Limited",
            "scope": "CONSOLIDATED",
            "fallback_unit": "crore",
            "file_count": "11",
        },
    )
    assert too_many.status_code == 422

    initialized = client.post(
        "/api/jobs/init",
        data={
            "company_name": "Example Limited",
            "scope": "CONSOLIDATED",
            "fallback_unit": "crore",
            "file_count": "2",
        },
    )
    assert initialized.status_code == 200
    job_id = initialized.json()["id"]

    first = client.post(
        f"/api/jobs/{job_id}/files",
        files={"file": ("fy2024.xml", b"<root/>", "application/xml")},
    )
    assert first.status_code == 200
    assert len(first.json()["files"]) == 1

    early_start = client.post(f"/api/jobs/{job_id}/start")
    assert early_start.status_code == 409

    second = client.post(
        f"/api/jobs/{job_id}/files",
        files={"file": ("fy2025.xml", b"<root/>", "application/xml")},
    )
    assert second.status_code == 200
    assert len(second.json()["files"]) == 2
    assert second.json()["expected_file_count"] == 2

    deleted = client.delete(f"/api/jobs/{job_id}")
    assert deleted.status_code == 200
