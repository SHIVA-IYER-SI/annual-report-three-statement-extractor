from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app


ROOT = Path(__file__).resolve().parents[1]


def test_github_pages_landing_assets_are_packaged():
    for relative in ("docs/index.html", "docs/landing.css", "docs/landing.js", "docs/config.js", "RUN_LOCALLY.md"):
        path = ROOT / relative
        assert path.is_file(), relative
        assert path.stat().st_size > 100


def test_health_supports_cross_origin_wake_request():
    client = TestClient(app)
    response = client.get("/api/health", headers={"Origin": "https://example.github.io"})
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.headers.get("access-control-allow-origin") == "*"


def test_open_source_and_contact_links_are_visible():
    landing = (ROOT / "docs/index.html").read_text(encoding="utf-8")
    app_page = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
    for content in (landing, app_page):
        assert "Download your own" in content
        assert "shivaiyer79@gmail.com" in content
