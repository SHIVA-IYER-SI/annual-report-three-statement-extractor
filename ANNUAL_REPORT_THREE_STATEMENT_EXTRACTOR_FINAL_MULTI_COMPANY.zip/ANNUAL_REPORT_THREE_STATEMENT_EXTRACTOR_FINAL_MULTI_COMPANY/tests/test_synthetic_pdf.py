from pathlib import Path

from openpyxl import load_workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.standalone_engine import extract_to_workbook


def _statement(story, title, rows):
    styles = getSampleStyleSheet()
    story.append(Paragraph(f"CONSOLIDATED {title}", styles["Heading2"]))
    story.append(Paragraph("(₹ in crore)", styles["Normal"]))
    story.append(Spacer(1, 8))
    data = [["Particulars", "Note", "31 March 2025", "31 March 2024"], *rows]
    table = Table(data, colWidths=[260, 45, 90, 90], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(table)


def make_pdf(path: Path):
    story = []
    _statement(
        story,
        "STATEMENT OF PROFIT AND LOSS",
        [
            ["Revenue from operations", "1", "1,000", "900"],
            ["Other income", "2", "50", "40"],
            ["Employee benefits expense", "3", "400", "350"],
            ["Finance costs", "4", "20", "18"],
            ["Depreciation and amortisation expense", "5", "50", "45"],
            ["Other expenses", "6", "300", "270"],
            ["Profit before tax", "", "280", "257"],
            ["Current tax", "", "70", "65"],
            ["Profit for the year", "", "210", "192"],
        ],
    )
    story.append(PageBreak())
    _statement(
        story,
        "BALANCE SHEET",
        [
            ["Property, plant and equipment", "7", "500", "480"],
            ["Cash and cash equivalents", "8", "290", "140"],
            ["Trade receivables", "9", "300", "250"],
            ["Total assets", "", "1,090", "870"],
            ["Share capital", "10", "100", "100"],
            ["Other equity", "11", "550", "400"],
            ["Borrowings", "12", "200", "190"],
            ["Trade payables", "13", "100", "90"],
            ["Other current liabilities", "14", "140", "90"],
            ["Total equity and liabilities", "", "1,090", "870"],
        ],
    )
    story.append(PageBreak())
    _statement(
        story,
        "STATEMENT OF CASH FLOWS",
        [
            ["Profit before tax", "", "280", "257"],
            ["Depreciation and amortisation", "", "50", "45"],
            ["Operating profit before working capital changes", "", "330", "302"],
            ["Cash generated from operations", "", "300", "280"],
            ["Income taxes paid", "", "(70)", "(65)"],
            ["Net cash from operating activities", "", "230", "215"],
            ["Purchase of property, plant and equipment", "", "(100)", "(90)"],
            ["Net cash used in investing activities", "", "(100)", "(90)"],
            ["Proceeds from borrowings", "", "50", "40"],
            ["Repayment of borrowings", "", "(30)", "(25)"],
            ["Net cash from financing activities", "", "20", "15"],
            ["Net increase in cash and cash equivalents", "", "150", "140"],
            ["Opening cash and cash equivalents", "", "140", "0"],
            ["Closing cash and cash equivalents", "", "290", "140"],
        ],
    )
    SimpleDocTemplate(str(path), pagesize=A4, rightMargin=24, leftMargin=24, topMargin=24, bottomMargin=24).build(story)


def test_synthetic_pdf_end_to_end(tmp_path: Path):
    pdf = tmp_path / "example_annual_report.pdf"
    make_pdf(pdf)
    result = extract_to_workbook(
        input_paths=[pdf],
        output_dir=tmp_path / "output",
        company_name="Example Limited",
        scope="CONSOLIDATED",
        fallback_unit="crore",
    )
    assert result.workbook_path.exists()
    workbook = load_workbook(result.workbook_path, data_only=False)
    assert workbook.sheetnames == ["INCOME STATEMENT", "BALANCE SHEET", "CASH FLOW STATEMENT"]
    assert result.statistics["raw_rows_detected"] >= 20
    assert result.statistics["selected_values"] >= 10
    assert result.years == [2024, 2025]
