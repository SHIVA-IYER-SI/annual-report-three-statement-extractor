from fastapi.testclient import TestClient
from app.main import app


def test_health_and_blueprint():
    client = TestClient(app)
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    blueprint = client.get("/api/blueprint")
    assert blueprint.status_code == 200
    assert blueprint.json()["line_item_counts"]["INCOME STATEMENT"] == 159
