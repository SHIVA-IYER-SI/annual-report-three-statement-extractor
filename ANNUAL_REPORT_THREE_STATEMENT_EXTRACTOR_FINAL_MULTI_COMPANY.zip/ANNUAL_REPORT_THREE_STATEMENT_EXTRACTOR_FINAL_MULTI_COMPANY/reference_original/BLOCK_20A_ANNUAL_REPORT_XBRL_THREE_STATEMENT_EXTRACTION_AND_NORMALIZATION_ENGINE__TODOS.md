# Block 20A TODOs and Honest Limitations

## Production integration

- Bind actual Block 6/7 raw-vault, upload and source-registry adapters.
- Implement the concrete Block 20 publisher against `ReportingPeriod`, three statement tables and `StatementLineItem`.
- Register models and router in the merged repository.
- Confirm migration `0015` is the single successor to `0014`.
- Bind shared artifact storage, authorization, Block 30A callback and downstream job queue.
- Merge frontend config edits carefully.

## TCS correction cycle

- Run representative TCS annual reports, annual-results PDFs and available XBRL.
- Validate page-local consolidated/standalone separation.
- Add robust continuation/repeated-header handling for observed layouts.
- Add approved TCS/template or context-restricted mapping rules.
- Add lawful/sanitized regression fixtures, not full copyrighted reports.
- Confirm overlapping comparative/restatement selection.
- Validate Cash Flow versus disclosed Balance Sheet cash-equivalent policy.
- Resolve/classify every material unmapped line.

## Extraction refinements

- Add cell-level bounding boxes where available.
- Propagate official publication timestamps from Block 30A/raw vault.
- Add linked attachment/note traversal.
- Expand Indian-taxonomy XBRL statement/scope inference.
- Add malformed Inline XBRL HTML fallback.
- Execute/tune optional OCR.
- Add model-assisted candidate proposals only if needed; deterministic fallback remains mandatory.

## Validation refinements

- Add canonical executors for each blueprint check once real mappings prove required inputs.
- Add disclosed cash-policy reconciliation, exact semantic cross-links and movement tests.
- Add formula-cache/recalculation testing in a controlled local environment.
- Apply wider tolerance only when source units justify it, capped at half the source unit.

## Review/frontend refinements

- Add separate reusable-rule approval UX.
- Add source snippet/page image beside review items.
- Add reviewer authorization once the real auth contract is available.
- Add run comparison UI.
- Add rule rollback/deprecation and regression gating.
- Run frontend install, lint, type-check and production build.
- Add authenticated blob download progress and auxiliary preview tabs.

## Tests not yet executed

- PostgreSQL migration/model test.
- FastAPI upload/API test.
- real TCS PDF/XBRL extraction.
- OCR execution.
- Block 20 publication and Block 21/22 handoff.
- Block 30A completion callback.
- frontend build/browser interaction.
- end-to-end preview/download.
