# Block 20A Implementation Plan

## 1. Controlling contracts

1. Use the verified Historical Three-Statement Extraction Blueprint v1.0 for workbook structure, canonical universes, dynamic-row policy, missing-data policy, formula policy, duplicate/restatement handling, validation, audit and acceptance.
2. Use the actual completed Kuberpath packages for repository paths, `Base`/`TimestampMixin`, instrument/source identity, Block 20 statement storage, status conventions, FastAPI, frontend shell, API client and migration order.
3. Keep extraction candidates in Block 20A staging; publish only an approved version into Block 20.
4. Keep Block 22A deferred and source-backed; never fabricate annual-report intelligence.

## 2. Runtime resources

- Package exact verified JSON resources needed at runtime.
- Hash-check them when `StatementExtractionEngine` initializes.
- Fail closed if a checksum or mapping/validation count differs.
- Preserve blueprint version and source ZIP checksum.

## 3. Input and evidence pipeline

1. Create a run with instrument, company, selected scope, output unit and selected years.
2. Register uploaded/raw-vault inputs and preserve Block 30A requirement links.
3. Validate file size, extension, MIME boundary, checksum and safe path.
4. Classify document type, scope, period, currency, unit and native/scanned state.
5. Extract native PDF tables or XBRL/iXBRL facts.
6. Store every candidate value before normalization with source file/page/context, original label/value/unit and confidence.
7. Preserve quarterly/interim evidence but exclude it from annual workbook columns.
8. Preserve unselected standalone/consolidated evidence without mixing it into the requested scope.

## 4. Mapping and normalization

1. Normalize labels without deleting original wording.
2. Score exact/synonym/context candidates against the 159/193/85 controlled universes.
3. Apply approved context-restricted mapping rules.
4. Force review for mandatory ambiguous terms.
5. Normalize supported units to INR crore while retaining original value/unit/scale.
6. Keep missing, disclosed zero, reported, restated, residual and cross-statement statuses distinct.
7. Create unmapped-line records rather than silently dropping rows.

## 5. Duplicate years and restatements

- Group candidates by selected scope, year and canonical key.
- Prefer the later clearly restated comparative according to the blueprint.
- Retain older evidence as `SUPERSEDED_COMPARATIVE`.
- Produce a restatement comparison artifact.
- Route unresolved material conflicts to review and block final export.

## 6. Dynamic assembly

- Include only disclosed rows, supported subtotals/totals, required links/checks and supported supplemental rows.
- Include required ancestors and remove empty headings.
- Keep one-year-only rows and leave undisclosed years blank.
- Preserve reported aggregates for partial detail; never invent a balancing “Other”.
- Compile formulas from canonical keys per year.

## 7. Validation and export gating

- Execute scope/unit/restatement/missing/duplicate/formula/lineage/dynamic-row/no-forecast controls.
- Execute critical Balance Sheet and Cash Flow reconciliations where inputs exist.
- Load all 58 blueprint validation definitions as versioned checks; missing-input checks remain `NOT_RUN`, never falsely passed.
- Block final export for critical/error failures, material unmapped lines, blocking review items, unexplained residuals, scope/unit ambiguity or material OCR uncertainty.
- Generate a clearly named review workbook when final criteria are not met.

## 8. Review and controlled learning

- Present source label, value, page/context, candidate keys and review reason.
- Support run-only, company/template and globally context-restricted corrections.
- Require reviewer and reason.
- Create a new mapping-rule version for reusable corrections.
- Preserve the original run and create an immutable child rerun.
- Compare mappings, values, review items and validation outcomes.

## 9. Artifacts and UI

- Generate workbook, extracted JSON, evidence CSV, validation JSON, unmapped CSV, review CSV, restatement CSV and audit-pack ZIP.
- Register checksums and opaque storage references.
- Present artifact cards with review/final state.
- Preview the structured workbook in a right-side drawer with exactly three statement tabs.
- Enable final `Download Excel` only when export eligible.

## 10. Publication and handoffs

- Publish approved normalized rows through a Block 20 adapter.
- Preserve run/version, period IDs, scope, source cutoff and evidence IDs.
- Create Block 21 and Block 22 refresh handoffs without duplicating their logic.
- Store a deferred Block 22A payload containing files, evidence, mappings, review/validation and approved artifact IDs.
- Update Block 30A only after its configured processing level is satisfied.

## 11. TCS correction cycle

- Integrate into the real repository and apply migration.
- Upload TCS annual reports/results/XBRL, select consolidated and run extraction.
- Correct only with source evidence, create scoped rules, rerun and compare.
- Approve/publish only after Balance Sheet/Cash Flow and every critical gate pass.
