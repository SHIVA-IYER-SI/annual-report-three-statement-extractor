# Block 20A — Annual Report / XBRL Three-Statement Extraction and Normalization Engine

## Delivery status

This package contains a production-shaped, locally runnable Block 20A implementation under `code/`. It converts registered PDF/XBRL inputs into a source-backed staging model, creates canonical mapping candidates, applies dynamic row rules, preserves duplicate/restatement evidence, runs validation, generates a review or final three-sheet Excel workbook, registers artifacts, exposes preview/download APIs, and provides a frontend extraction/review/artifact experience.

It does **not** claim universal annual-report extraction accuracy. Native digital PDF and XML/iXBRL baselines are implemented. Scanned-page handling is adapter-based and blocks approval when OCR is unavailable or materially uncertain. Real TCS documents are not included.

## Mandatory blueprint verification

The attached `Historical_3_Statement_Extraction_Blueprint_v1.0.zip` was extracted and every payload file under `00_MASTER/` through `06_QA_AND_AUDIT/` was inspected, including all instructions, JSON resources, Excel references/templates, workbook builder, QA workbook, manifest and checksum file.

Verified values:

- Blueprint ZIP SHA-256: `1dc7653d23a6c8f195520ae5196a87aaf7fd287394aa3bb2e80213ee51b47073`
- Internal version: `1.0`, generated `2026-07-09`
- `MANIFEST.csv`: 49 payload rows; no missing or unlisted payload files
- `SHA256SUMS.txt`: every listed payload hash matched
- Income Statement mapping universe: 159 entries
- Balance Sheet mapping universe: 193 entries
- Cash Flow Statement mapping universe: 85 entries
- Income Statement validation universe: 16 checks
- Balance Sheet validation universe: 27 checks
- Cash Flow Statement validation universe: 15 checks

The exact runtime resources copied from the verified blueprint are listed in `code/app/services/statement_extraction/resources/blueprint_resource_manifest.json`, with original path, byte count and SHA-256. The original blueprint ZIP is intentionally not nested in this delivery.

## Workbook contract implemented

The workbook builder enforces:

- exactly `INCOME STATEMENT`, `BALANCE SHEET`, `CASH FLOW STATEMENT`;
- no forecast period;
- dynamic disclosure-driven rows;
- consolidated default, standalone only when selected;
- INR crore output;
- blank undisclosed values and explicit visible zero;
- Column A spacer, Column B labels, years from Column C;
- `ACTUAL` on row 1 and `YEAR` on row 2;
- freeze panes `C3`, hidden gridlines, Arial 10;
- actual-period fill `#C6EFCE`, supplemental fill `#D9D9D9`;
- two-decimal display, red negatives and italic percentages;
- canonical-key formulas rather than fixed Excel row references;
- formula-injection protection for untrusted labels/text;
- review workbook versus final workbook export gating.

Auxiliary evidence, validation, unmapped-line, manual-review and restatement outputs are separate artifacts, not extra sheets in the main workbook.

## Implementation coverage

Included:

- SQLAlchemy staging/evidence/review/artifact models;
- Alembic revision `0015` with `down_revision = 0014`;
- typed Pydantic contracts;
- repositories and transaction-owned services;
- native PDF text/table baseline using `pdfplumber`;
- scanned-page detection and optional OCR adapter boundary;
- XML XBRL and Inline XBRL context/unit/fact parsing;
- page-local scope and annual/interim separation controls;
- immutable evidence records;
- canonical candidate scoring with mandatory ambiguity review;
- controlled reusable mapping-rule versions;
- duplicate/restatement selection without deleting superseded evidence;
- dynamic row assembly and canonical-key formula compiler;
- validation and export eligibility;
- manual corrections, immutable child reruns and run comparison;
- review/final workbook generation plus audit-pack artifacts;
- Block 20 publication port and Block 21/22 handoff records;
- deferred Block 22A handoff contract;
- Block 30A requirement-processing callback port;
- internal FastAPI routes, secure file intake, artifact preview and download;
- Next.js extraction page, review controls, artifact card, side-panel preview and history;
- CLI using the same service layer as the API;
- focused deterministic tests.

## Direct execution evidence in this environment

Executed against the delivered code:

- Python bytecode compilation completed without syntax errors.
- Focused test suite: `19 passed` using `PYTHONPATH=code pytest -q code/tests/statement_extraction`.

The tests cover blueprint resource integrity, mapping/validation counts, numeric parsing, missing-versus-zero, unit conversion, restatement selection, dynamic rows, ambiguity handling, workbook contract, exact sheet names, formatting invariants, artifact naming and formula-injection protection.

## Not executed or claimed

- no real TCS PDF/XBRL extraction;
- no OCR execution;
- no PostgreSQL migration execution;
- no backend or worker startup;
- no Block 20 publication against a live database;
- no Block 30A callback against a live service;
- no frontend install/build/type-check/render;
- no browser artifact preview/download test;
- no Git commit or push.

Use the included TCS runbook for local integration and correction-based testing.
