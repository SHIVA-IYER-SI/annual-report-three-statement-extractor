# TCS-First Local Runbook for Block 20A

This runbook describes the first real correction cycle on the second laptop. It does not include TCS documents and does not assume first-run extraction accuracy.

## 1. Integrate on a clean branch

1. Branch from the repository state containing Blocks 1–30A.
2. Extract this ZIP outside the repository.
3. Copy `code/` contents into the repository root while preserving paths.
4. Review collisions in frontend config, model registration, API router composition, requirements and migration order.
5. Do not copy dependency ZIPs or the original blueprint ZIP into Git.

## 2. Verify packaged blueprint resources

Run from the backend environment:

```bash
python - <<'PYVERIFY20A'
from app.services.statement_extraction.resources import verify_runtime_resources
errors = verify_runtime_resources()
print(errors)
raise SystemExit(1 if errors else 0)
PYVERIFY20A
```

Expected output is `[]`. Any mismatch must stop the run.

## 3. Install dependencies

Merge `requirements/block20a.txt` into the repository’s backend dependency process. Use the existing SQLAlchemy, FastAPI and Pydantic versions. OCR is optional and requires both the Python package and local Tesseract executable. No external LLM is required.

## 4. Configure local environment

Use repository-standard settings. For the local adapter, configure a writable storage root and PostgreSQL URL:

```text
KUBERPATH_LOCAL_STORAGE_DIR=<local-writable-directory>
KUBERPATH_DATABASE_URL=<local-postgresql-sqlalchemy-url>
```

Do not commit a real `.env` file.

Inspect migration heads:

```bash
alembic heads
alembic history --verbose
```

Confirm Block 30A is `0014` and Block 20A is the only `0015` successor, then run the repository-approved migration:

```bash
alembic upgrade head
```

The migration was not executed during ZIP creation.

## 5. Wire the application

- Import `app.models.statement_extraction` through the existing model registry.
- Include `app.api.routers.statement_extraction.router` under the internal API router.
- Bind the actual raw-vault and artifact-storage adapters.
- Bind the Block 30A callback.
- Keep Block 20 publishing disabled until its adapter is reviewed.

## 6. Start services

Use the repository’s established commands. A typical FastAPI command may resemble:

```bash
uvicorn app.main:app --reload
```

Use the package manager and existing `frontend/` scripts selected by Block 30. Do not create another frontend application or lockfile.

## 7. Prepare lawful official TCS files

Recommended first set:

- recent consolidated TCS annual report PDF;
- immediately prior annual report PDF for overlapping comparatives;
- official XBRL/iXBRL for one period if available;
- optionally an annual-results filing.

Do not add source documents to Git. Register official source URL, publication date, source ID and Block 30A requirement IDs through the real upload/raw-vault flow.

## 8. UI workflow

1. Open `/fundamentals/extraction`.
2. Select/enter the real TCS Instrument Master ID.
3. Confirm company display name.
4. Keep `CONSOLIDATED` and INR crore.
5. Select official files.
6. Create the run and start extraction.
7. Wait for `REVIEW_REQUIRED` or `EXPORT_READY`.
8. Inspect all three preview tabs and validation state.
9. Open each review item and its source evidence before correcting it.

Upload alone is not validation and must not complete a Block 30A requirement.

## 9. CLI workflow

The CLI uses the same service layer as the API:

```bash
PYTHONPATH=. python -m app.services.statement_extraction.cli \
  --company "Tata Consultancy Services Limited" \
  --instrument-id <TCS_INSTRUMENT_ID> \
  --scope consolidated \
  --input /path/to/TCS_Annual_Report_FY2026.pdf \
  --input /path/to/TCS_Annual_Report_FY2025.pdf \
  --output /path/to/local/output \
  --database-url "$KUBERPATH_DATABASE_URL" \
  --review-mode-export
```

Optional additions:

```bash
  --input /path/to/TCS_FY2026_XBRL.xml \
  --year 2022 --year 2023 --year 2024 --year 2025 --year 2026
```

Exit codes:

- `0`: completed for the requested mode;
- `2`: input validation failed;
- `3`: review required when review-mode export is not allowed;
- other non-zero: processing failure.

## 10. Review sequence

Review in this order:

1. Document classification: company, annual period, publication metadata, native/scanned state.
2. Scope: every selected statement/table must be consolidated.
3. Units: confirm statement/note units and INR crore scaling.
4. Years: no quarterly/interim fact in an annual column.
5. Restatements: compare overlapping reports and select the latest clearly restated comparative.
6. Mapping: original label, parent/table context, page and candidate keys.
7. Dynamic rows: no universe-wide blanks or empty parents; one-year-only rows retained.
8. Aggregate/detail: preserve reported aggregate if detail is partial; no invented “Other”.
9. Duplicate economics: one source line cannot own multiple economic model rows.
10. Validation: Balance Sheet, Cash Flow roll-forward, cash policy and material unmapped lines.

## 11. Apply corrections safely

Use a source-backed reason for every correction.

- `RUN_ONLY`: one-off extraction issue.
- `COMPANY_OR_REPORT_TEMPLATE`: repeatable TCS/template-specific behavior.
- `GLOBAL_CONTEXT_RESTRICTED`: only when label plus parent/note/classification context is unambiguous across companies.

Never promote a bare ambiguous synonym globally. Special caution applies to training fees, interest accrued, security deposits, current maturities, lease liabilities, unbilled revenue, deferred revenue, cash credit, dividends and JV profit/dividend.

After resolving review items, create an immutable child rerun. Do not restart and mutate the original run.

## 12. Compare reruns

Compare:

- canonical mappings;
- normalized values;
- resolved and new review items;
- validation outcomes;
- workbook rows/formulas;
- mapping-rule version.

Retain old runs and artifacts for audit.

## 13. Workbook acceptance

Before final approval verify:

- exactly three sheets with exact names;
- no forecast columns;
- one consistent scope;
- source/formula lineage for every populated value;
- blank and zero remain distinct;
- latest valid restated comparatives selected;
- no empty parent heading or duplicate economic value;
- Balance Sheet balances within approved tolerance;
- Cash Flow opening + movement = closing;
- closing cash reconciles to Balance Sheet net cash under the disclosed policy;
- material unmapped lines and critical OCR ambiguity resolved;
- no unexplained residual or plug;
- artifact is `FINAL_WORKBOOK`, not `REVIEW_WORKBOOK`.

Only then should the primary `Download Excel` action be available.

## 14. Download and audit

- Compare preview values with the artifact source payload.
- Download the exact generated workbook filename.
- Download the audit pack.
- Retain evidence, validation, unmapped, review and restatement artifacts.
- Record run ID, artifact ID, mapping version and workbook checksum.

## 15. Publish downstream

After approval:

1. publish through the reviewed Block 20 adapter;
2. confirm new Block 20 period/revision records and lineage;
3. dispatch Block 21 ratio and Block 22 red-flag handoffs;
4. preserve the deferred Block 22A payload;
5. update Block 30A to the configured processed/validated completion level.

Never publish an unresolved review run to Block 20.

## 16. Report failures

Capture:

- run ID;
- input filename/checksum and official source metadata;
- page/table/snippet where permitted;
- expected scope/year/unit/row;
- extracted result;
- review/validation IDs;
- failure class: parser, OCR, mapping, restatement, formula, validation, artifact or UI;
- proposed correction scope and regression case.

Do not fix failures by hardcoding TCS values, years, page numbers or note numbers.
