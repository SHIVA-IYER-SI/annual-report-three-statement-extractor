"use client";
import { FormEvent, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { AccountingScope, CreateExtractionRunRequest } from "@/types/statement-extraction";
import styles from "./statement-extraction.module.css";
interface Props { busy?: boolean; onCreate: (payload: CreateExtractionRunRequest, files: File[]) => Promise<void>; }
export function ExtractionRunForm({ busy, onCreate }: Props) {
  const [company, setCompany] = useState(""); const [instrumentId, setInstrumentId] = useState(""); const [scope, setScope] = useState<"CONSOLIDATED" | "STANDALONE">("CONSOLIDATED"); const [files, setFiles] = useState<File[]>([]);
  async function submit(event: FormEvent) { event.preventDefault(); if (!company || !instrumentId || files.length === 0) return; await onCreate({ instrument_id: Number(instrumentId), company_name: company, scope, output_currency: "INR", output_unit: "CRORE", selected_years: [], latest_restated_comparative: true, inputs: [] }, files); }
  return <form className={styles.form} onSubmit={submit}>
    <div className={styles.formGrid}><label>Company name<Input value={company} onChange={(e) => setCompany(e.target.value)} required /></label><label>Instrument ID<Input type="number" min="1" value={instrumentId} onChange={(e) => setInstrumentId(e.target.value)} required /></label><label>Accounting scope<select value={scope} onChange={(e) => setScope(e.target.value as typeof scope)}><option value="CONSOLIDATED">Consolidated</option><option value="STANDALONE">Standalone</option></select></label><label>Annual reports / results / XBRL<input type="file" accept=".pdf,.xml,.xhtml,.html" multiple onChange={(e) => setFiles(Array.from(e.target.files ?? []))} required /></label></div>
    <p className={styles.helper}>Consolidated and INR crore are the defaults. Files are evidence inputs; upload alone does not mean validation or completion.</p>
    <Button type="submit" disabled={busy || files.length === 0}>{busy ? "Creating run…" : "Create extraction run"}</Button>
  </form>;
}
