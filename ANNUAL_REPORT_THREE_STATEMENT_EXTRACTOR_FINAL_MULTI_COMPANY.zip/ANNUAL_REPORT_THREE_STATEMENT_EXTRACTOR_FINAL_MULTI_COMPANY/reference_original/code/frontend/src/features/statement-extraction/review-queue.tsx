"use client";
import { FormEvent, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import type { CorrectionRequest, ReviewItem } from "@/types/statement-extraction";
import styles from "./statement-extraction.module.css";

interface Props { items: ReviewItem[]; busy?: boolean; onResolve: (itemId: number, payload: CorrectionRequest) => Promise<void>; }
export function ReviewQueue({ items, busy, onResolve }: Props) {
  const [openId, setOpenId] = useState<number>();
  if (!items.length) return null;
  return <section><h2>Manual review</h2><div className={styles.reviewList}>{items.map((item) => <Card key={item.id} className={styles.reviewItem}>
    <div><strong>{item.severity} · {item.item_type}</strong><p>{item.reason}</p>{item.recommended_action ? <small>{item.recommended_action}</small> : null}</div>
    <div><span>{item.blocks_final_export ? "Blocks final Excel" : "Review warning"}</span><Button variant="secondary" onClick={() => setOpenId(openId === item.id ? undefined : item.id)}>{openId === item.id ? "Close" : "Resolve"}</Button></div>
    {openId === item.id ? <CorrectionForm busy={busy} onSubmit={(payload) => onResolve(item.id, payload)} /> : null}
  </Card>)}</div></section>;
}
function CorrectionForm({ busy, onSubmit }: { busy?: boolean; onSubmit: (payload: CorrectionRequest) => Promise<void> }) {
  const [action, setAction] = useState<CorrectionRequest["action"]>("SELECT_CANONICAL_KEY"); const [scope, setScope] = useState<CorrectionRequest["correction_scope"]>("RUN_ONLY"); const [reviewer, setReviewer] = useState(""); const [reason, setReason] = useState(""); const [canonicalKey, setCanonicalKey] = useState(""); const [value, setValue] = useState(""); const [unit, setUnit] = useState("");
  async function submit(event: FormEvent) { event.preventDefault(); await onSubmit({ action, correction_scope: scope, corrected_by: reviewer, reason, canonical_key: canonicalKey || undefined, corrected_value: value || undefined, corrected_unit: unit || undefined, context: {} }); }
  return <form className={styles.correctionForm} onSubmit={submit}><label>Action<select value={action} onChange={(e) => setAction(e.target.value as CorrectionRequest["action"])}><option value="SELECT_CANONICAL_KEY">Select canonical key</option><option value="CONFIRM_MAPPING">Confirm mapping</option><option value="CORRECT_VALUE">Correct value</option><option value="CORRECT_SIGN">Correct sign</option><option value="CORRECT_UNIT">Correct unit</option><option value="CLASSIFY_DISCLOSED_ZERO">Classify disclosed zero</option><option value="CLASSIFY_MISSING">Classify missing</option><option value="MARK_DUPLICATE">Mark duplicate</option><option value="MARK_SUPERSEDED">Mark superseded</option><option value="EXCLUDE_NARRATIVE">Exclude narrative</option><option value="APPROVE_RESIDUAL">Approve residual</option></select></label><label>Rule scope<select value={scope} onChange={(e) => setScope(e.target.value as CorrectionRequest["correction_scope"])}><option value="RUN_ONLY">Current run only</option><option value="COMPANY_OR_REPORT_TEMPLATE">Company/report template</option><option value="GLOBAL_CONTEXT_RESTRICTED">Reviewed context-restricted global rule</option></select></label><label>Canonical key<Input value={canonicalKey} onChange={(e) => setCanonicalKey(e.target.value)} placeholder="Required for mapping actions" /></label><label>Corrected value<Input value={value} onChange={(e) => setValue(e.target.value)} inputMode="decimal" /></label><label>Corrected unit<Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="crore, lakh, million…" /></label><label>Reviewer<Input value={reviewer} onChange={(e) => setReviewer(e.target.value)} required /></label><label>Reason<textarea value={reason} onChange={(e) => setReason(e.target.value)} minLength={3} required /></label><Button type="submit" disabled={busy}>{busy ? "Saving…" : "Save reviewed correction"}</Button></form>;
}
