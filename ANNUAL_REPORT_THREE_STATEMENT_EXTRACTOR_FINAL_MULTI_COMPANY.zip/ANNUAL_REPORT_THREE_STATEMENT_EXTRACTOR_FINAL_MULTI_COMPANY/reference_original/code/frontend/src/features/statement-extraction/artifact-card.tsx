import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { statementExtractionApi } from "@/lib/api/modules/statement-extraction";
import type { Artifact } from "@/types/statement-extraction";
import styles from "./statement-extraction.module.css";
interface Props { artifact: Artifact; company: string; scope: string; years: string[]; onPreview: () => void; }
export function ArtifactCard({ artifact, company, scope, years, onPreview }: Props) {
  const isWorkbook = artifact.artifact_type === "FINAL_WORKBOOK" || artifact.artifact_type === "REVIEW_WORKBOOK";
  return <Card className={styles.artifactCard}><div className={styles.fileIcon} aria-hidden="true">XLSX</div><div className={styles.artifactBody}><div className={styles.artifactTitle}><strong>{artifact.filename}</strong><StatusBadge status={artifact.review_required ? "REVIEW_REQUIRED" : "AVAILABLE"} label={artifact.review_required ? "Review required" : "Ready"} /></div><p>{company} · {scope} · {years.join("–")} · v{artifact.version}</p><div className={styles.artifactMeta}><span>{artifact.critical_error_count} critical</span><span>{artifact.warning_count} warnings</span><span>{artifact.size_bytes ? `${Math.ceil(artifact.size_bytes / 1024)} KB` : "Size pending"}</span></div></div><div className={styles.actions}>{artifact.preview_available ? <Button variant="secondary" onClick={onPreview}>Open / Preview</Button> : null}{artifact.download_available ? <a className="button" href={statementExtractionApi.downloadUrl(artifact.id)} download={artifact.filename}>{isWorkbook && artifact.review_required ? "Download Review Workbook" : isWorkbook ? "Download Excel" : "Download"}</a> : <Button disabled>Final download blocked</Button>}</div></Card>;
}
