import { StatementExtractionPage } from "@/features/statement-extraction/extraction-page";
export default function Page() { return <StatementExtractionPage />; }
