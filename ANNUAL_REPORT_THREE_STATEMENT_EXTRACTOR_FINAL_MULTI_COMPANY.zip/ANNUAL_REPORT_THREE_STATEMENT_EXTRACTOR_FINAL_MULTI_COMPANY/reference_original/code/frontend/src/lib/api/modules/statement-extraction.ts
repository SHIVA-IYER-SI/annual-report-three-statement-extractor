import { apiClient, buildApiUrl } from "@/lib/api/client";
import { KuberpathApiError } from "@/lib/api/errors";
import type { Artifact, ArtifactPreview, CorrectionRequest, CorrectionResult, CreateExtractionRunRequest, ExtractionRun, ReviewItem, RunComparison } from "@/types/statement-extraction";

export const statementExtractionApi = {
  createRun: (payload: CreateExtractionRunRequest) => apiClient.post<ExtractionRun>("/statement-extraction/runs", payload),
  startRun: (runId: number) => apiClient.post<ExtractionRun>(`/statement-extraction/runs/${runId}/start`),
  run: (runId: number) => apiClient.get<ExtractionRun>(`/statement-extraction/runs/${runId}`),
  runs: (query: { instrument_id?: number; status?: string; limit?: number; offset?: number }) => apiClient.get<{ items: ExtractionRun[]; total: number; limit: number; offset: number }>("/statement-extraction/runs", query),
  artifacts: (runId: number) => apiClient.get<Artifact[]>(`/statement-extraction/runs/${runId}/artifacts`),
  preview: (artifactId: number) => apiClient.get<ArtifactPreview>(`/statement-extraction/artifacts/${artifactId}/preview`),
  reviewItems: (runId: number, status = "OPEN") => apiClient.get<ReviewItem[]>(`/statement-extraction/runs/${runId}/review-items`, { status }),
  resolveReview: (runId: number, itemId: number, payload: CorrectionRequest) => apiClient.post<CorrectionResult>(`/statement-extraction/runs/${runId}/review-items/${itemId}/resolve`, payload),
  rerun: (runId: number, payload: { reviewer: string; mapping_rule_version?: string }) => apiClient.post<ExtractionRun>(`/statement-extraction/runs/${runId}/rerun`, payload),
  compare: (parentRunId: number, childRunId: number) => apiClient.get<RunComparison>(`/statement-extraction/runs/${parentRunId}/compare/${childRunId}`),
  downloadUrl: (artifactId: number) => buildApiUrl(`/statement-extraction/artifacts/${artifactId}/download`).toString(),
  async upload(runId: number, file: File, associations: { requirementId?: number; requirementGroupId?: number; sourceId?: number } = {}) {
    const form = new FormData(); form.set("file", file);
    if (associations.requirementId) form.set("requirement_id", String(associations.requirementId));
    if (associations.requirementGroupId) form.set("requirement_group_id", String(associations.requirementGroupId));
    if (associations.sourceId) form.set("source_id", String(associations.sourceId));
    const response = await fetch(buildApiUrl(`/statement-extraction/runs/${runId}/files`), { method: "POST", body: form, credentials: "same-origin" });
    if (!response.ok) throw new KuberpathApiError({ message: "Document upload failed.", status: response.status, endpoint: response.url });
    return (await response.json()) as unknown;
  },
};
