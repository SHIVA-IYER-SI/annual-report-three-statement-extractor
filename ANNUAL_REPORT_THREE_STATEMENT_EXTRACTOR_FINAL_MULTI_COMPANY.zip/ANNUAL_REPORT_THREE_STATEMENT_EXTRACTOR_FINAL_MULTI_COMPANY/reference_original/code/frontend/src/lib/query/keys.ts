export const queryKeys = {
 dataRequirements: (filters: object) => ["data-requirements", "active", filters] as const,
 statementExtractionRuns: (instrumentId?: number) => ["statement-extraction", "runs", instrumentId] as const,
 statementExtractionRun: (runId: number) => ["statement-extraction", "run", runId] as const,
 statementExtractionArtifacts: (runId: number) => ["statement-extraction", "artifacts", runId] as const,
 events: (filters: Record<string, unknown>) => ["events", filters] as const, checklistFamilies: () => ["checklists", "families"] as const,
 creditSummary: (instrumentId: number, asOf: string) => ["credit", "summary", instrumentId, asOf] as const,
 fnoSummary: (instrumentId: number, asOf: string) => ["derivatives", "summary", instrumentId, asOf] as const,
 candidates: (filters: Record<string, unknown>) => ["candidate-scoring", "candidates", filters] as const,
 candidate: (candidateId: number) => ["candidate-scoring", "candidate", candidateId] as const,
 memo: (memoId: number) => ["memos", memoId] as const, memoHistory: (instrumentId: number) => ["memos", "instrument", instrumentId] as const,
} as const;
