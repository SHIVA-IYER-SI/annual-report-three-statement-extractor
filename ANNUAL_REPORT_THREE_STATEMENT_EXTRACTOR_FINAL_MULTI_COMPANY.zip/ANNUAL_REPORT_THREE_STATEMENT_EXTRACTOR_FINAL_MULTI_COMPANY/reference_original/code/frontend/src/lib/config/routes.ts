export interface NavigationItem { label: string; href: string; icon: string; exact?: boolean; internalOnly?: boolean; }
export interface NavigationGroup { label: string; items: readonly NavigationItem[]; }
export const navigationGroups: readonly NavigationGroup[] = [
 { label: "Research", items: [{ label: "Overview", href: "/", icon: "⌂", exact: true },{ label: "Stock Search", href: "/stocks", icon: "⌕" },{ label: "Manual Mode", href: "/manual", icon: "✎" },{ label: "Screeners", href: "/screeners", icon: "▦" },{ label: "AI Candidates", href: "/ai/candidates", icon: "◇" }] },
 { label: "Evidence Desks", items: [{ label: "Events", href: "/events", icon: "◷" },{ label: "Fundamentals", href: "/fundamentals", icon: "ƒ" },{ label: "Statement Extraction", href: "/fundamentals/extraction", icon: "▤", internalOnly: true },{ label: "Credit", href: "/credit", icon: "₵" },{ label: "F&O Intelligence", href: "/derivatives", icon: "Δ" },{ label: "Research Memos", href: "/memos", icon: "▤" }] },
 { label: "System", items: [{ label: "Daily Requirements", href: "/data-requirements", icon: "✓", internalOnly: true },{ label: "Developer Dashboard", href: "/developer", icon: "⚙", internalOnly: true },{ label: "Settings", href: "/settings", icon: "◐" }] },
] as const;
