from datetime import date,datetime,timezone
from decimal import Decimal
from app.services.statement_extraction.restatements import RestatementCandidate,resolve

def test_latest_report_comparative_selected():
    a=RestatementCandidate(1,2024,"is.total",Decimal("100"),date(2024,5,1),datetime(2024,5,1,tzinfo=timezone.utc),False,"old.pdf")
    b=RestatementCandidate(2,2024,"is.total",Decimal("105"),date(2025,5,1),datetime(2025,5,1,tzinfo=timezone.utc),True,"new.pdf")
    d=resolve([a,b]);assert d.selected.evidence_id==2;assert d.is_restated;assert d.superseded[0].evidence_id==1
