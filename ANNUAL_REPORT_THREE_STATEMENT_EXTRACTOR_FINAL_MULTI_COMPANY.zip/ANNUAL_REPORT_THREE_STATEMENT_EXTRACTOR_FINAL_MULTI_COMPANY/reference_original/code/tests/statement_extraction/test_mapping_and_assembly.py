from decimal import Decimal
from app.services.statement_extraction.mapping import CanonicalMapper
from app.services.statement_extraction.assembly import DynamicStatementAssembler,SelectedValue,workbook_payload

def test_exact_revenue_mapping():
    c=CanonicalMapper().candidates("INCOME_STATEMENT","Revenue from operations")
    assert c and c[0].canonical_key=="is.revenue.section"
def test_ambiguous_training_requires_context_review():
    mapper=CanonicalMapper();c=mapper.candidates("INCOME_STATEMENT","Training fees")
    assert mapper.needs_mandatory_review("Training fees",c,"") is True

def test_dynamic_rows_omit_undisclosed_and_include_ancestors():
    selected=[SelectedValue(1,"INCOME_STATEMENT","is.revenue.products",2025,Decimal("10"),"REPORTED"),SelectedValue(2,"INCOME_STATEMENT","is.revenue.products",2026,Decimal("12"),"REPORTED")]
    assembled=DynamicStatementAssembler().assemble(selected,[2025,2026]);keys=[r.key for r in assembled["INCOME_STATEMENT"]]
    assert "is.revenue.products" in keys;assert "is.revenue.section" in keys;assert "is.revenue.services" not in keys

def test_one_year_only_row_keeps_other_year_blank():
    selected=[SelectedValue(1,"INCOME_STATEMENT","is.revenue.products",2026,Decimal("12"),"REPORTED")]
    row=next(r for r in DynamicStatementAssembler().assemble(selected,[2025,2026])["INCOME_STATEMENT"] if r.key=="is.revenue.products")
    assert "FY25" not in row.values and row.values["FY26"]==Decimal("12")
