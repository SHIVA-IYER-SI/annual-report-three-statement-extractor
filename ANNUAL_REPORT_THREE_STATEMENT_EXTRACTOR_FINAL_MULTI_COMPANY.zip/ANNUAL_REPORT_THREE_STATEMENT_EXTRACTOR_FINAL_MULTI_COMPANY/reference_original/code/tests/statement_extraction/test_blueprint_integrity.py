from app.services.statement_extraction.resources import EXPECTED_COUNTS,line_item_universes,validation_universes,verify_runtime_resources,load_json

def test_runtime_resources_match_verified_blueprint(): assert verify_runtime_resources()==[]
def test_mapping_counts():
    u=line_item_universes();assert len(u["INCOME_STATEMENT"])==159;assert len(u["BALANCE_SHEET"])==193;assert len(u["CASH_FLOW_STATEMENT"])==85
def test_validation_counts():
    v=validation_universes();assert len(v["INCOME_STATEMENT"])==16;assert len(v["BALANCE_SHEET"])==27;assert len(v["CASH_FLOW_STATEMENT"])==15
def test_output_contract():
    c=load_json("output_contract.json");assert c["sheets"]==["INCOME STATEMENT","BALANCE SHEET","CASH FLOW STATEMENT"];assert c["no_forecast"] is True;assert c["view"]["freeze_panes"]=="C3"
