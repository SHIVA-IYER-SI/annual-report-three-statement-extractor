from decimal import Decimal
from app.services.statement_extraction.parsing import parse_number,normalize_to_crore,detect_unit,parse_financial_year

def test_commas_and_brackets():
    assert parse_number("1,234.50").value==Decimal("1234.50");assert parse_number("(1,234.50)").value==Decimal("-1234.50")
def test_disclosed_zero_and_missing_are_distinct():
    assert parse_number("Nil").status=="DISCLOSED_ZERO";assert parse_number("").status=="MISSING_NOT_DISCLOSED";assert parse_number("-").status=="AMBIGUOUS_REVIEW_REQUIRED";assert parse_number("-",dash_means_zero=True).value==0
def test_unit_conversion():
    assert normalize_to_crore(Decimal("100"),"lakh")==Decimal("1.00");assert normalize_to_crore(Decimal("100"),"million")==Decimal("10.0");assert normalize_to_crore(Decimal("10"),"crore")==Decimal("10")
def test_year_and_unit_detection():
    assert parse_financial_year("Year ended 31 March 2026")==2026;assert detect_unit("Amounts in ₹ crores")=="crore"
