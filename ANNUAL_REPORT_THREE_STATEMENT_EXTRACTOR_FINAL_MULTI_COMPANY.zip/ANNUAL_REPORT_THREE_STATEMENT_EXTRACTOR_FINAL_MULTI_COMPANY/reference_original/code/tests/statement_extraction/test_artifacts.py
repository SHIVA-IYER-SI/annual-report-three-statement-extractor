from app.services.statement_extraction.artifacts import deterministic_workbook_filename

def test_safe_deterministic_filename():
    name=deterministic_workbook_filename("TCS / Tata Consultancy Services","CONSOLIDATED",[2021,2026],"1")
    assert name.endswith(".xlsx") and "/" not in name and "FY2021_FY2026" in name
