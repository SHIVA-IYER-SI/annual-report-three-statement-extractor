from decimal import Decimal
from app.services.statement_extraction.validation import StatementValidator

def test_missing_is_not_zero_violation_is_critical():
    class V: status="MISSING_NOT_DISCLOSED";value=Decimal(0);evidence_id=1;statement_type="INCOME_STATEMENT";canonical_key="x";financial_year=2025;source={}
    s=StatementValidator().validate(scope_values={"CONSOLIDATED"},units={"INR_CRORE"},selected_values=[V()],assembled={"INCOME_STATEMENT":[],"BALANCE_SHEET":[],"CASH_FLOW_STATEMENT":[]},years=[2025])
    assert any(f.check_id=="G-04" and f.outcome=="FAIL" for f in s.findings)
