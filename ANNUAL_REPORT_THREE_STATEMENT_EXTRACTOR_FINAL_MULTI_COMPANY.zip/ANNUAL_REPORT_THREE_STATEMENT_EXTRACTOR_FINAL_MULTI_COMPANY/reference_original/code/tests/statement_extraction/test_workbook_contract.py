from pathlib import Path
from openpyxl import load_workbook
from app.services.statement_extraction.workbook import build_workbook,assert_workbook_contract,SHEET_ORDER

def payload():
    return {"company_name":"Example","scope":"consolidated","currency_unit":"INR_crore","years":["FY25","FY26"],"statements":{
      "INCOME STATEMENT":[{"key":"is.revenue","label":"Revenue from Operations","row_type":"major_total","value_type":"currency","hierarchy_level":0,"include":True,"values":{"FY25":"10","FY26":"12"},"sources":{}}],
      "BALANCE SHEET":[{"key":"bs.assets","label":"Total Assets","row_type":"major_total","value_type":"currency","hierarchy_level":0,"include":True,"values":{"FY25":"20","FY26":"25"},"sources":{}}],
      "CASH FLOW STATEMENT":[{"key":"cf.net","label":"Total Net Change in Cash and Cash Equivalents","row_type":"major_total","value_type":"currency","hierarchy_level":0,"include":True,"values":{"FY25":"2","FY26":"3"},"sources":{}}],}}
def test_exact_three_sheet_format(tmp_path:Path):
    p=tmp_path/"model.xlsx";build_workbook(payload()).save(p);wb=load_workbook(p)
    assert wb.sheetnames==SHEET_ORDER
    for ws in wb.worksheets:assert ws.freeze_panes=="C3" and ws.sheet_view.showGridLines is False and ws["B2"].value=="YEAR"
    assert assert_workbook_contract(p)==[]
def test_no_forecast_allowed():
    p=payload();p["years"]=["FORECAST 2027"]
    import pytest
    with pytest.raises(ValueError):build_workbook(p)
