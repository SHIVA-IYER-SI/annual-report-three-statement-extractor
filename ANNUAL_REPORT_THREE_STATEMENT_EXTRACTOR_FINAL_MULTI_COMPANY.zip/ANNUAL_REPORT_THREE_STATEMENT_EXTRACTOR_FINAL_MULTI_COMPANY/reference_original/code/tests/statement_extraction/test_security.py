from app.services.statement_extraction.security import escape_excel_text,safe_filename

def test_formula_injection_is_escaped():
    assert escape_excel_text("=WEBSERVICE('x')").startswith("'")
    assert escape_excel_text("Normal label")=="Normal label"
def test_safe_filename(): assert safe_filename("../../TCS?.pdf")=="TCS_.pdf"
