"""Block 20A annual-report/XBRL extraction, review and artifact models.

Block 20 remains the permanent normalized statement store.  These tables are
staging, evidence, review, immutable-run, artifact and publication records.
String vocabularies are used rather than PostgreSQL enums, matching the current
Kuberpath house convention.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any

from sqlalchemy import BigInteger, Boolean, Date, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin

AMOUNT = Numeric(28, 8)
CONFIDENCE = Numeric(8, 6)

class ExtractionRunStatus(StrEnum):
    CREATED="CREATED"; FILES_REGISTERED="FILES_REGISTERED"; CLASSIFYING_DOCUMENTS="CLASSIFYING_DOCUMENTS"
    DETECTING_STATEMENTS="DETECTING_STATEMENTS"; EXTRACTING="EXTRACTING"; NORMALIZING="NORMALIZING"
    RESOLVING_RESTATEMENTS="RESOLVING_RESTATEMENTS"; ASSEMBLING_MODEL="ASSEMBLING_MODEL"; VALIDATING="VALIDATING"
    REVIEW_REQUIRED="REVIEW_REQUIRED"; CORRECTION_PENDING="CORRECTION_PENDING"; REGENERATING="REGENERATING"
    EXPORT_READY="EXPORT_READY"; COMPLETED="COMPLETED"; FAILED="FAILED"; SUPERSEDED="SUPERSEDED"; CANCELLED="CANCELLED"

class AccountingScope(StrEnum):
    CONSOLIDATED="CONSOLIDATED"; STANDALONE="STANDALONE"; AMBIGUOUS="AMBIGUOUS"; UNKNOWN="UNKNOWN"

class DocumentType(StrEnum):
    ANNUAL_REPORT="ANNUAL_REPORT"; ANNUAL_RESULTS="ANNUAL_RESULTS"; QUARTERLY_RESULTS="QUARTERLY_RESULTS"
    XBRL="XBRL"; INLINE_XBRL="INLINE_XBRL"; OTHER_FINANCIAL_DOCUMENT="OTHER_FINANCIAL_DOCUMENT"; UNKNOWN="UNKNOWN"

class StatementType(StrEnum):
    INCOME_STATEMENT="INCOME_STATEMENT"; BALANCE_SHEET="BALANCE_SHEET"; CASH_FLOW_STATEMENT="CASH_FLOW_STATEMENT"
    NOTE="NOTE"; SEGMENT="SEGMENT"; OTHER="OTHER"

class ValueStatus(StrEnum):
    REPORTED="REPORTED"; REPORTED_RESTATED="REPORTED_RESTATED"
    CALCULATED_FROM_DISCLOSED_COMPONENTS="CALCULATED_FROM_DISCLOSED_COMPONENTS"
    CALCULATED_RESIDUAL="CALCULATED_RESIDUAL"; CROSS_STATEMENT_LINK="CROSS_STATEMENT_LINK"
    DISCLOSED_ZERO="DISCLOSED_ZERO"; MISSING_NOT_DISCLOSED="MISSING_NOT_DISCLOSED"
    AMBIGUOUS_REVIEW_REQUIRED="AMBIGUOUS_REVIEW_REQUIRED"; SUPERSEDED_COMPARATIVE="SUPERSEDED_COMPARATIVE"

class ReviewStatus(StrEnum):
    OPEN="OPEN"; RESOLVED="RESOLVED"; ACCEPTED="ACCEPTED"; REJECTED="REJECTED"; SUPERSEDED="SUPERSEDED"

class ReviewSeverity(StrEnum):
    CRITICAL="CRITICAL"; ERROR="ERROR"; WARNING="WARNING"; INFORMATIONAL="INFORMATIONAL"

class ValidationOutcome(StrEnum):
    PASS="PASS"; FAIL="FAIL"; WARNING="WARNING"; INFORMATIONAL="INFORMATIONAL"; NOT_APPLICABLE="NOT_APPLICABLE"; NOT_RUN="NOT_RUN"

class ArtifactType(StrEnum):
    FINAL_WORKBOOK="FINAL_WORKBOOK"; REVIEW_WORKBOOK="REVIEW_WORKBOOK"; EXTRACTED_DATA_JSON="EXTRACTED_DATA_JSON"
    SOURCE_EVIDENCE="SOURCE_EVIDENCE"; VALIDATION_REPORT="VALIDATION_REPORT"; UNMAPPED_LINES="UNMAPPED_LINES"
    MANUAL_REVIEW="MANUAL_REVIEW"; RESTATEMENT_COMPARISON="RESTATEMENT_COMPARISON"; AUDIT_PACK="AUDIT_PACK"

class ArtifactStatus(StrEnum):
    GENERATING="GENERATING"; REVIEW_REQUIRED="REVIEW_REQUIRED"; READY="READY"; FAILED="FAILED"; SUPERSEDED="SUPERSEDED"

class CorrectionScope(StrEnum):
    RUN_ONLY="RUN_ONLY"; COMPANY_OR_REPORT_TEMPLATE="COMPANY_OR_REPORT_TEMPLATE"; GLOBAL_CONTEXT_RESTRICTED="GLOBAL_CONTEXT_RESTRICTED"

class HandoffDestination(StrEnum):
    BLOCK_20="BLOCK_20"; BLOCK_21="BLOCK_21"; BLOCK_22="BLOCK_22"; BLOCK_22A="BLOCK_22A"; BLOCK_30A="BLOCK_30A"

class HandoffStatus(StrEnum):
    PENDING="PENDING"; READY="READY"; DISPATCHED="DISPATCHED"; COMPLETED="COMPLETED"; FAILED="FAILED"; DEFERRED_NOT_BUILT="DEFERRED_NOT_BUILT"

class StatementExtractionRun(Base, TimestampMixin):
    __tablename__="statement_extraction_runs"
    __table_args__=(UniqueConstraint("run_uid",name="uq_statement_extraction_runs_uid"),
                    UniqueConstraint("instrument_id","scope","version_number",name="uq_statement_extraction_runs_instrument_scope_version"),
                    Index("ix_statement_extraction_runs_lookup","instrument_id","scope","status"),
                    Index("ix_statement_extraction_runs_parent","parent_run_id"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_uid: Mapped[str]=mapped_column(String(64),nullable=False)
    instrument_id: Mapped[int]=mapped_column(ForeignKey("instruments.id",ondelete="RESTRICT"),nullable=False)
    company_name: Mapped[str]=mapped_column(String(255),nullable=False)
    scope: Mapped[str]=mapped_column(String(24),nullable=False,default=AccountingScope.CONSOLIDATED)
    output_currency: Mapped[str]=mapped_column(String(3),nullable=False,default="INR")
    output_unit: Mapped[str]=mapped_column(String(24),nullable=False,default="CRORE")
    selected_years: Mapped[list[str]]=mapped_column(JSONB,nullable=False,default=list)
    status: Mapped[str]=mapped_column(String(40),nullable=False,default=ExtractionRunStatus.CREATED)
    review_required: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    extraction_engine_version: Mapped[str]=mapped_column(String(64),nullable=False)
    mapping_rule_version: Mapped[str]=mapped_column(String(64),nullable=False)
    validation_rule_version: Mapped[str]=mapped_column(String(64),nullable=False)
    workbook_format_version: Mapped[str]=mapped_column(String(64),nullable=False)
    evidence_cutoff_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    started_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    failure_code: Mapped[str | None]=mapped_column(String(128))
    failure_reason: Mapped[str | None]=mapped_column(Text)
    parent_run_id: Mapped[int | None]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="SET NULL"))
    version_number: Mapped[int]=mapped_column(Integer,nullable=False,default=1)
    is_current_approved: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    approved_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    approved_by: Mapped[str | None]=mapped_column(String(255))
    details: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    inputs: Mapped[list["StatementExtractionInput"]]=relationship(back_populates="run",cascade="all, delete-orphan")
    evidence: Mapped[list["StatementSourceEvidence"]]=relationship(back_populates="run",cascade="all, delete-orphan")
    artifacts: Mapped[list["StatementExtractionArtifact"]]=relationship(back_populates="run",cascade="all, delete-orphan")

class StatementExtractionInput(Base, TimestampMixin):
    __tablename__="statement_extraction_inputs"
    __table_args__=(UniqueConstraint("run_id","checksum",name="uq_statement_extraction_inputs_run_checksum"),Index("ix_statement_extraction_inputs_refs","raw_vault_reference","requirement_id"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    requirement_id: Mapped[int | None]=mapped_column(ForeignKey("document_requirement_instances.id",ondelete="SET NULL"))
    requirement_group_id: Mapped[int | None]=mapped_column(ForeignKey("document_requirement_groups.id",ondelete="SET NULL"))
    source_id: Mapped[int | None]=mapped_column(ForeignKey("source_registry.id",ondelete="SET NULL"))
    raw_vault_reference: Mapped[str | None]=mapped_column(String(255))
    original_filename: Mapped[str]=mapped_column(String(500),nullable=False)
    safe_filename: Mapped[str]=mapped_column(String(500),nullable=False)
    mime_type: Mapped[str | None]=mapped_column(String(128))
    size_bytes: Mapped[int | None]=mapped_column(BigInteger)
    checksum: Mapped[str]=mapped_column(String(128),nullable=False)
    source_url: Mapped[str | None]=mapped_column(String(1200))
    local_processing_reference: Mapped[str | None]=mapped_column(String(1000))
    input_metadata: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    run: Mapped[StatementExtractionRun]=relationship(back_populates="inputs")
    classification: Mapped["StatementDocumentClassification | None"]=relationship(back_populates="input",uselist=False,cascade="all, delete-orphan")

class StatementDocumentClassification(Base, TimestampMixin):
    __tablename__="statement_document_classifications"
    __table_args__=(UniqueConstraint("input_id",name="uq_statement_document_classifications_input"),Index("ix_statement_document_classifications_year_scope","financial_year","scope"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    input_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_inputs.id",ondelete="CASCADE"),nullable=False)
    document_type: Mapped[str]=mapped_column(String(40),nullable=False)
    company_name_detected: Mapped[str | None]=mapped_column(String(255))
    financial_year: Mapped[int | None]=mapped_column(Integer)
    period_start: Mapped[date | None]=mapped_column(Date)
    period_end: Mapped[date | None]=mapped_column(Date)
    publication_date: Mapped[date | None]=mapped_column(Date)
    scope: Mapped[str]=mapped_column(String(24),nullable=False)
    available_scopes: Mapped[list[str]]=mapped_column(JSONB,nullable=False,default=list)
    currency: Mapped[str | None]=mapped_column(String(3))
    reporting_unit: Mapped[str | None]=mapped_column(String(32))
    page_count: Mapped[int | None]=mapped_column(Integer)
    native_pdf: Mapped[bool | None]=mapped_column(Boolean)
    scanned_pages: Mapped[list[int]]=mapped_column(JSONB,nullable=False,default=list)
    xbrl_kind: Mapped[str | None]=mapped_column(String(32))
    is_revision: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    classification_confidence: Mapped[Decimal | None]=mapped_column(CONFIDENCE)
    review_required_reason: Mapped[str | None]=mapped_column(Text)
    classification_metadata: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    input: Mapped[StatementExtractionInput]=relationship(back_populates="classification")

class StatementSourceEvidence(Base, TimestampMixin):
    __tablename__="statement_source_evidence"
    __table_args__=(Index("ix_statement_source_evidence_lookup","run_id","statement_type","financial_year","canonical_key"),Index("ix_statement_source_evidence_input_page","input_id","page_number"),Index("ix_statement_source_evidence_selected","run_id","selected_for_model"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    input_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_inputs.id",ondelete="CASCADE"),nullable=False)
    instrument_id: Mapped[int]=mapped_column(ForeignKey("instruments.id",ondelete="RESTRICT"),nullable=False)
    source_id: Mapped[int | None]=mapped_column(ForeignKey("source_registry.id",ondelete="SET NULL"))
    accounting_scope: Mapped[str]=mapped_column(String(24),nullable=False)
    financial_year: Mapped[int | None]=mapped_column(Integer)
    period_start: Mapped[date | None]=mapped_column(Date)
    period_end: Mapped[date | None]=mapped_column(Date)
    statement_type: Mapped[str]=mapped_column(String(40),nullable=False)
    note_number: Mapped[str | None]=mapped_column(String(64))
    table_title: Mapped[str | None]=mapped_column(String(500))
    parent_label: Mapped[str | None]=mapped_column(String(500))
    original_label: Mapped[str]=mapped_column(Text,nullable=False)
    original_value_text: Mapped[str | None]=mapped_column(Text)
    original_value_numeric: Mapped[Decimal | None]=mapped_column(AMOUNT)
    original_currency: Mapped[str | None]=mapped_column(String(3))
    original_unit: Mapped[str | None]=mapped_column(String(32))
    scale_factor_to_crore: Mapped[Decimal | None]=mapped_column(AMOUNT)
    normalized_value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    value_status: Mapped[str]=mapped_column(String(64),nullable=False)
    page_number: Mapped[int | None]=mapped_column(Integer)
    bounding_box: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    source_snippet: Mapped[str | None]=mapped_column(Text)
    extraction_method: Mapped[str]=mapped_column(String(64),nullable=False)
    extraction_confidence: Mapped[Decimal | None]=mapped_column(CONFIDENCE)
    xbrl_concept: Mapped[str | None]=mapped_column(String(500))
    xbrl_context_id: Mapped[str | None]=mapped_column(String(255))
    xbrl_unit_id: Mapped[str | None]=mapped_column(String(255))
    xbrl_decimals: Mapped[str | None]=mapped_column(String(64))
    canonical_key: Mapped[str | None]=mapped_column(String(255))
    mapping_rule_id: Mapped[int | None]=mapped_column(ForeignKey("statement_mapping_rules.id",ondelete="SET NULL"))
    mapping_confidence: Mapped[Decimal | None]=mapped_column(CONFIDENCE)
    selected_for_model: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    review_note: Mapped[str | None]=mapped_column(Text)
    first_seen_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    extracted_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    evidence_metadata: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    run: Mapped[StatementExtractionRun]=relationship(back_populates="evidence")

class StatementMappingRuleVersion(Base, TimestampMixin):
    __tablename__="statement_mapping_rule_versions"
    __table_args__=(UniqueConstraint("version",name="uq_statement_mapping_rule_versions_version"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    version: Mapped[str]=mapped_column(String(64),nullable=False)
    parent_version_id: Mapped[int | None]=mapped_column(ForeignKey("statement_mapping_rule_versions.id",ondelete="SET NULL"))
    blueprint_version: Mapped[str]=mapped_column(String(32),nullable=False)
    status: Mapped[str]=mapped_column(String(24),nullable=False,default="ACTIVE")
    approved_by: Mapped[str | None]=mapped_column(String(255))
    approved_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    change_summary: Mapped[str | None]=mapped_column(Text)

class StatementMappingRule(Base, TimestampMixin):
    __tablename__="statement_mapping_rules"
    __table_args__=(UniqueConstraint("version_id","rule_uid",name="uq_statement_mapping_rules_version_uid"),Index("ix_statement_mapping_rules_match","statement_type","normalized_label","canonical_key"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    version_id: Mapped[int]=mapped_column(ForeignKey("statement_mapping_rule_versions.id",ondelete="RESTRICT"),nullable=False)
    rule_uid: Mapped[str]=mapped_column(String(64),nullable=False)
    correction_scope: Mapped[str]=mapped_column(String(40),nullable=False)
    company_instrument_id: Mapped[int | None]=mapped_column(ForeignKey("instruments.id",ondelete="SET NULL"))
    report_template_fingerprint: Mapped[str | None]=mapped_column(String(128))
    statement_type: Mapped[str]=mapped_column(String(40),nullable=False)
    original_label: Mapped[str]=mapped_column(Text,nullable=False)
    normalized_label: Mapped[str]=mapped_column(Text,nullable=False)
    parent_context: Mapped[str | None]=mapped_column(Text)
    note_context: Mapped[str | None]=mapped_column(Text)
    classification_context: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    canonical_key: Mapped[str]=mapped_column(String(255),nullable=False)
    sign_rule: Mapped[str | None]=mapped_column(String(64))
    unit_rule: Mapped[str | None]=mapped_column(String(64))
    approved_by: Mapped[str | None]=mapped_column(String(255))
    approved_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    is_active: Mapped[bool]=mapped_column(Boolean,nullable=False,default=True)
    regression_example: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)

class StatementMappingCandidate(Base, TimestampMixin):
    __tablename__="statement_mapping_candidates"
    __table_args__=(UniqueConstraint("evidence_id","canonical_key",name="uq_statement_mapping_candidates_evidence_key"),Index("ix_statement_mapping_candidates_review","run_id","selected","confidence"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    evidence_id: Mapped[int]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="CASCADE"),nullable=False)
    canonical_key: Mapped[str]=mapped_column(String(255),nullable=False)
    score: Mapped[Decimal]=mapped_column(CONFIDENCE,nullable=False)
    confidence: Mapped[Decimal]=mapped_column(CONFIDENCE,nullable=False)
    reasons: Mapped[list[str]]=mapped_column(JSONB,nullable=False,default=list)
    selected: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    mapping_rule_version: Mapped[str]=mapped_column(String(64),nullable=False)

class StatementNormalizedRow(Base, TimestampMixin):
    __tablename__="statement_normalized_rows"
    __table_args__=(UniqueConstraint("run_id","statement_type","canonical_key",name="uq_statement_normalized_rows_run_key"),Index("ix_statement_normalized_rows_order","run_id","statement_type","display_order"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    statement_type: Mapped[str]=mapped_column(String(40),nullable=False)
    canonical_key: Mapped[str]=mapped_column(String(255),nullable=False)
    display_label: Mapped[str]=mapped_column(String(500),nullable=False)
    parent_key: Mapped[str | None]=mapped_column(String(255))
    hierarchy_level: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    row_type: Mapped[str]=mapped_column(String(40),nullable=False)
    value_type: Mapped[str]=mapped_column(String(24),nullable=False)
    display_order: Mapped[int]=mapped_column(Integer,nullable=False)
    formula_definition: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    inclusion_reason: Mapped[str]=mapped_column(String(128),nullable=False)
    blank_after: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)

class StatementNormalizedValue(Base, TimestampMixin):
    __tablename__="statement_normalized_values"
    __table_args__=(UniqueConstraint("row_id","financial_year",name="uq_statement_normalized_values_row_year"),Index("ix_statement_normalized_values_run_year","run_id","financial_year"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    row_id: Mapped[int]=mapped_column(ForeignKey("statement_normalized_rows.id",ondelete="CASCADE"),nullable=False)
    financial_year: Mapped[int]=mapped_column(Integer,nullable=False)
    value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    value_status: Mapped[str]=mapped_column(String(64),nullable=False)
    evidence_id: Mapped[int | None]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="SET NULL"))
    formula_definition: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    source_precision: Mapped[int | None]=mapped_column(Integer)

class StatementRestatementComparison(Base, TimestampMixin):
    __tablename__="statement_restatement_comparisons"
    __table_args__=(Index("ix_statement_restatement_comparisons_lookup","run_id","financial_year","canonical_key"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    financial_year: Mapped[int]=mapped_column(Integer,nullable=False)
    canonical_key: Mapped[str]=mapped_column(String(255),nullable=False)
    older_evidence_id: Mapped[int]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="RESTRICT"),nullable=False)
    later_evidence_id: Mapped[int]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="RESTRICT"),nullable=False)
    older_value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    later_value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    difference: Mapped[Decimal | None]=mapped_column(AMOUNT)
    selected_evidence_id: Mapped[int | None]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="SET NULL"))
    is_restated: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    explanation: Mapped[str | None]=mapped_column(Text)

class StatementValidationRun(Base, TimestampMixin):
    __tablename__="statement_validation_runs"
    __table_args__=(UniqueConstraint("run_id","version",name="uq_statement_validation_runs_run_version"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    version: Mapped[str]=mapped_column(String(64),nullable=False)
    started_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    completed_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    critical_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    error_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    warning_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    passed_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    export_eligible: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)

class StatementValidationResult(Base, TimestampMixin):
    __tablename__="statement_validation_results"
    __table_args__=(UniqueConstraint("validation_run_id","check_id","financial_year",name="uq_statement_validation_results_check_year"),Index("ix_statement_validation_results_severity","run_id","severity","outcome"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    validation_run_id: Mapped[int]=mapped_column(ForeignKey("statement_validation_runs.id",ondelete="CASCADE"),nullable=False)
    check_id: Mapped[str]=mapped_column(String(64),nullable=False)
    check_name: Mapped[str]=mapped_column(String(255),nullable=False)
    statement_type: Mapped[str | None]=mapped_column(String(40))
    financial_year: Mapped[int | None]=mapped_column(Integer)
    severity: Mapped[str]=mapped_column(String(32),nullable=False)
    outcome: Mapped[str]=mapped_column(String(32),nullable=False)
    observed_value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    expected_value: Mapped[Decimal | None]=mapped_column(AMOUNT)
    difference: Mapped[Decimal | None]=mapped_column(AMOUNT)
    tolerance: Mapped[Decimal | None]=mapped_column(AMOUNT)
    message: Mapped[str]=mapped_column(Text,nullable=False)
    evidence_ids: Mapped[list[int]]=mapped_column(JSONB,nullable=False,default=list)
    details: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)

class StatementUnmappedLine(Base, TimestampMixin):
    __tablename__="statement_unmapped_lines"
    __table_args__=(Index("ix_statement_unmapped_lines_review","run_id","materiality","review_status"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    evidence_id: Mapped[int]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="CASCADE"),nullable=False)
    candidate_keys: Mapped[list[dict[str,Any]]]=mapped_column(JSONB,nullable=False,default=list)
    confidence: Mapped[Decimal | None]=mapped_column(CONFIDENCE)
    reason_not_selected: Mapped[str]=mapped_column(String(128),nullable=False)
    materiality: Mapped[str]=mapped_column(String(32),nullable=False)
    review_status: Mapped[str]=mapped_column(String(32),nullable=False,default=ReviewStatus.OPEN)
    reviewer_decision: Mapped[str | None]=mapped_column(Text)

class StatementReviewItem(Base, TimestampMixin):
    __tablename__="statement_review_items"
    __table_args__=(Index("ix_statement_review_items_open","run_id","status","severity"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    evidence_id: Mapped[int | None]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="SET NULL"))
    validation_result_id: Mapped[int | None]=mapped_column(ForeignKey("statement_validation_results.id",ondelete="SET NULL"))
    item_type: Mapped[str]=mapped_column(String(64),nullable=False)
    severity: Mapped[str]=mapped_column(String(32),nullable=False)
    status: Mapped[str]=mapped_column(String(32),nullable=False,default=ReviewStatus.OPEN)
    reason: Mapped[str]=mapped_column(Text,nullable=False)
    recommended_action: Mapped[str | None]=mapped_column(Text)
    blocks_final_export: Mapped[bool]=mapped_column(Boolean,nullable=False,default=True)
    resolved_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    resolved_by: Mapped[str | None]=mapped_column(String(255))
    resolution: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)

class StatementManualCorrection(Base, TimestampMixin):
    __tablename__="statement_manual_corrections"
    __table_args__=(Index("ix_statement_manual_corrections_run_scope","run_id","correction_scope"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    review_item_id: Mapped[int]=mapped_column(ForeignKey("statement_review_items.id",ondelete="RESTRICT"),nullable=False)
    evidence_id: Mapped[int | None]=mapped_column(ForeignKey("statement_source_evidence.id",ondelete="SET NULL"))
    correction_scope: Mapped[str]=mapped_column(String(40),nullable=False)
    action: Mapped[str]=mapped_column(String(64),nullable=False)
    before_state: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    after_state: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    reason: Mapped[str]=mapped_column(Text,nullable=False)
    corrected_by: Mapped[str]=mapped_column(String(255),nullable=False)
    corrected_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    proposed_rule_id: Mapped[int | None]=mapped_column(ForeignKey("statement_mapping_rules.id",ondelete="SET NULL"))

class StatementExtractionArtifact(Base, TimestampMixin):
    __tablename__="statement_extraction_artifacts"
    __table_args__=(UniqueConstraint("artifact_uid",name="uq_statement_extraction_artifacts_uid"),UniqueConstraint("run_id","artifact_type","version",name="uq_statement_extraction_artifacts_run_type_version"),Index("ix_statement_extraction_artifacts_status","run_id","status"))
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    artifact_uid: Mapped[str]=mapped_column(String(64),nullable=False)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    artifact_type: Mapped[str]=mapped_column(String(64),nullable=False)
    filename: Mapped[str]=mapped_column(String(500),nullable=False)
    mime_type: Mapped[str]=mapped_column(String(128),nullable=False)
    size_bytes: Mapped[int | None]=mapped_column(BigInteger)
    checksum: Mapped[str | None]=mapped_column(String(128))
    storage_reference: Mapped[str]=mapped_column(String(1000),nullable=False)
    status: Mapped[str]=mapped_column(String(32),nullable=False)
    version: Mapped[str]=mapped_column(String(64),nullable=False)
    generated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    critical_error_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    warning_count: Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    review_required: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    download_available: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    preview_available: Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    superseded_artifact_id: Mapped[int | None]=mapped_column(ForeignKey("statement_extraction_artifacts.id",ondelete="SET NULL"))
    artifact_metadata: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    run: Mapped[StatementExtractionRun]=relationship(back_populates="artifacts")

class StatementPublication(Base, TimestampMixin):
    __tablename__="statement_extraction_publications"
    __table_args__=(UniqueConstraint("run_id",name="uq_statement_extraction_publications_run"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="RESTRICT"),nullable=False)
    reporting_period_ids: Mapped[list[int]]=mapped_column(JSONB,nullable=False,default=list)
    published_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    published_by: Mapped[str]=mapped_column(String(255),nullable=False)
    adapter_version: Mapped[str]=mapped_column(String(64),nullable=False)
    status: Mapped[str]=mapped_column(String(32),nullable=False)
    details: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)

class StatementDownstreamHandoff(Base, TimestampMixin):
    __tablename__="statement_extraction_handoffs"
    __table_args__=(Index("ix_statement_extraction_handoffs_status","run_id","destination","status"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    destination: Mapped[str]=mapped_column(String(32),nullable=False)
    status: Mapped[str]=mapped_column(String(32),nullable=False)
    payload_reference: Mapped[str | None]=mapped_column(String(1000))
    payload: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
    created_at_business: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    completed_at: Mapped[datetime | None]=mapped_column(DateTime(timezone=True))
    error_message: Mapped[str | None]=mapped_column(Text)

class StatementExtractionAuditEvent(Base, TimestampMixin):
    __tablename__="statement_extraction_audit_events"
    __table_args__=(Index("ix_statement_extraction_audit_events_run_time","run_id","occurred_at"),)
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("statement_extraction_runs.id",ondelete="CASCADE"),nullable=False)
    event_type: Mapped[str]=mapped_column(String(64),nullable=False)
    occurred_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    actor: Mapped[str | None]=mapped_column(String(255))
    message: Mapped[str]=mapped_column(Text,nullable=False)
    event_data: Mapped[dict[str,Any]]=mapped_column(JSONB,nullable=False,default=dict)
