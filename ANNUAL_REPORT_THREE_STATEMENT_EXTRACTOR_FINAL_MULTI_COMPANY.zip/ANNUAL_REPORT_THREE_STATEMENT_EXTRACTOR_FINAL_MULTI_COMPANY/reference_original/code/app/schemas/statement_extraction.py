"""Typed API contracts for Block 20A."""
from __future__ import annotations
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from app.models.statement_extraction import AccountingScope, ArtifactStatus, ArtifactType, CorrectionScope, ExtractionRunStatus, ReviewSeverity, ReviewStatus, ValidationOutcome, ValueStatus

class ORMModel(BaseModel): model_config=ConfigDict(from_attributes=True)

class ExtractionInputRef(BaseModel):
    raw_vault_reference: str | None=None
    requirement_id: int | None=None
    requirement_group_id: int | None=None
    source_id: int | None=None
    original_filename: str
    checksum: str
    mime_type: str | None=None
    size_bytes: int | None=Field(default=None,ge=0)
    source_url: str | None=None
    local_processing_reference: str | None=None
    metadata: dict[str,Any]=Field(default_factory=dict)
    @model_validator(mode="after")
    def require_reference(self):
        if not self.raw_vault_reference and not self.local_processing_reference:
            raise ValueError("raw_vault_reference or local_processing_reference is required")
        return self

class CreateExtractionRunRequest(BaseModel):
    instrument_id: int
    company_name: str=Field(min_length=1,max_length=255)
    scope: AccountingScope=AccountingScope.CONSOLIDATED
    output_currency: str="INR"
    output_unit: Literal["CRORE"]="CRORE"
    selected_years: list[int]=Field(default_factory=list)
    latest_restated_comparative: bool=True
    output_version_label: str | None=None
    inputs: list[ExtractionInputRef]=Field(default_factory=list)

class ExtractionInputOut(ORMModel):
    id:int; run_id:int; requirement_id:int|None; requirement_group_id:int|None; source_id:int|None
    raw_vault_reference:str|None; original_filename:str; safe_filename:str; mime_type:str|None; size_bytes:int|None; checksum:str
    source_url:str|None; local_processing_reference:str|None; input_metadata:dict[str,Any]

class DocumentClassificationOut(ORMModel):
    id:int; input_id:int; document_type:str; company_name_detected:str|None; financial_year:int|None
    period_start:date|None; period_end:date|None; publication_date:date|None; scope:AccountingScope
    available_scopes:list[str]; currency:str|None; reporting_unit:str|None; page_count:int|None; native_pdf:bool|None
    scanned_pages:list[int]; xbrl_kind:str|None; is_revision:bool; classification_confidence:Decimal|None
    review_required_reason:str|None; classification_metadata:dict[str,Any]

class ExtractionRunSummaryOut(ORMModel):
    id:int; run_uid:str; instrument_id:int; company_name:str; scope:AccountingScope; output_currency:str; output_unit:str
    selected_years:list[str]; status:ExtractionRunStatus; review_required:bool; extraction_engine_version:str
    mapping_rule_version:str; validation_rule_version:str; workbook_format_version:str; version_number:int
    is_current_approved:bool; created_at:datetime; started_at:datetime|None; completed_at:datetime|None
    failure_code:str|None; failure_reason:str|None

class ExtractionRunDetailOut(ExtractionRunSummaryOut):
    inputs:list[ExtractionInputOut]=Field(default_factory=list)
    progress:list["ProgressStageOut"]=Field(default_factory=list)
    validation_summary:"ValidationSummaryOut | None"=None
    artifacts:list["ArtifactOut"]=Field(default_factory=list)
    open_review_items:int=0

class ProgressStageOut(BaseModel):
    code:str; label:str; state:Literal["PENDING","RUNNING","COMPLETED","FAILED","REVIEW_REQUIRED"]; completed:int=0; total:int|None=None; message:str|None=None; timestamp:datetime|None=None

class SourceEvidenceOut(ORMModel):
    id:int; run_id:int; input_id:int; instrument_id:int; source_id:int|None; accounting_scope:AccountingScope
    financial_year:int|None; period_start:date|None; period_end:date|None; statement_type:str; note_number:str|None
    table_title:str|None; parent_label:str|None; original_label:str; original_value_text:str|None
    original_value_numeric:Decimal|None; original_currency:str|None; original_unit:str|None; scale_factor_to_crore:Decimal|None
    normalized_value:Decimal|None; value_status:ValueStatus; page_number:int|None; bounding_box:dict[str,Any]
    source_snippet:str|None; extraction_method:str; extraction_confidence:Decimal|None; xbrl_concept:str|None
    xbrl_context_id:str|None; xbrl_unit_id:str|None; xbrl_decimals:str|None; canonical_key:str|None
    mapping_confidence:Decimal|None; selected_for_model:bool; review_note:str|None; first_seen_at:datetime|None; extracted_at:datetime

class MappingCandidateOut(ORMModel):
    id:int; evidence_id:int; canonical_key:str; score:Decimal; confidence:Decimal; reasons:list[str]; selected:bool; mapping_rule_version:str

class NormalizedValueOut(ORMModel):
    financial_year:int; value:Decimal|None; value_status:ValueStatus; evidence_id:int|None; formula_definition:dict[str,Any]

class NormalizedRowOut(ORMModel):
    id:int; statement_type:str; canonical_key:str; display_label:str; parent_key:str|None; hierarchy_level:int
    row_type:str; value_type:str; display_order:int; formula_definition:dict[str,Any]; inclusion_reason:str; blank_after:bool
    values:list[NormalizedValueOut]=Field(default_factory=list)

class ValidationResultOut(ORMModel):
    id:int; check_id:str; check_name:str; statement_type:str|None; financial_year:int|None; severity:str; outcome:ValidationOutcome
    observed_value:Decimal|None; expected_value:Decimal|None; difference:Decimal|None; tolerance:Decimal|None
    message:str; evidence_ids:list[int]; details:dict[str,Any]

class ValidationSummaryOut(BaseModel):
    critical_count:int=0; error_count:int=0; warning_count:int=0; passed_count:int=0; export_eligible:bool=False
    scope_consistent:bool=False; balance_sheet_balances:bool=False; cash_flow_reconciles:bool=False
    no_unexplained_plug:bool=False; no_material_unmapped_lines:bool=False; exact_missing_conditions:list[str]=Field(default_factory=list)

class ReviewItemOut(ORMModel):
    id:int; run_id:int; evidence_id:int|None; validation_result_id:int|None; item_type:str; severity:ReviewSeverity
    status:ReviewStatus; reason:str; recommended_action:str|None; blocks_final_export:bool; resolved_at:datetime|None
    resolved_by:str|None; resolution:dict[str,Any]

class CorrectionRequest(BaseModel):
    action: Literal["CONFIRM_MAPPING","SELECT_CANONICAL_KEY","CORRECT_VALUE","CORRECT_SIGN","CORRECT_UNIT","CORRECT_YEAR","CORRECT_SCOPE","CLASSIFY_DISCLOSED_ZERO","CLASSIFY_MISSING","MARK_DUPLICATE","MARK_SUPERSEDED","EXCLUDE_NARRATIVE","ROLL_INTO_AGGREGATE","APPROVE_RESIDUAL","ASSOCIATE_SOURCE","CREATE_MAPPING_RULE"]
    correction_scope: CorrectionScope=CorrectionScope.RUN_ONLY
    corrected_by: str
    reason: str=Field(min_length=3)
    canonical_key: str | None=None
    corrected_value: Decimal | None=None
    corrected_unit: str | None=None
    corrected_year: int | None=None
    corrected_scope: AccountingScope | None=None
    source_page: int | None=None
    note_number: str | None=None
    company_template_fingerprint: str | None=None
    context: dict[str,Any]=Field(default_factory=dict)

class CorrectionOut(ORMModel):
    id:int; run_id:int; review_item_id:int; evidence_id:int|None; correction_scope:CorrectionScope; action:str
    before_state:dict[str,Any]; after_state:dict[str,Any]; reason:str; corrected_by:str; corrected_at:datetime; proposed_rule_id:int|None

class RerunRequest(BaseModel):
    reviewer: str
    apply_run_only_corrections: bool=True
    apply_company_rules: bool=True
    apply_global_context_rules: bool=True
    mapping_rule_version: str | None=None

class RunComparisonOut(BaseModel):
    parent_run_id:int; child_run_id:int; changed_mappings:list[dict[str,Any]]=Field(default_factory=list)
    changed_values:list[dict[str,Any]]=Field(default_factory=list); resolved_review_items:list[int]=Field(default_factory=list)
    new_review_items:list[int]=Field(default_factory=list); validation_changes:list[dict[str,Any]]=Field(default_factory=list)

class ArtifactOut(ORMModel):
    id:int; artifact_uid:str; run_id:int; artifact_type:ArtifactType; filename:str; mime_type:str; size_bytes:int|None
    checksum:str|None; status:ArtifactStatus; version:str; generated_at:datetime; critical_error_count:int; warning_count:int
    review_required:bool; download_available:bool; preview_available:bool; superseded_artifact_id:int|None; artifact_metadata:dict[str,Any]

class PreviewCellOut(BaseModel):
    raw_value:str|Decimal|None=None; display_value:str|None=None; formula:dict[str,Any]|None=None; status:str|None=None
    evidence_ids:list[int]=Field(default_factory=list); source_page:int|None=None; review_required:bool=False; missing:bool=False

class PreviewRowOut(BaseModel):
    key:str; label:str; row_type:str; value_type:str; hierarchy_level:int=0; cells:dict[str,PreviewCellOut]; blank_after:bool=False

class PreviewSheetOut(BaseModel):
    name:Literal["INCOME STATEMENT","BALANCE SHEET","CASH FLOW STATEMENT"]; years:list[str]; rows:list[PreviewRowOut]

class ArtifactPreviewOut(BaseModel):
    artifact:ArtifactOut; company_name:str; scope:AccountingScope; years:list[str]; validation_summary:ValidationSummaryOut
    sheets:list[PreviewSheetOut]; auxiliary_counts:dict[str,int]=Field(default_factory=dict)

class PublishRunRequest(BaseModel):
    published_by:str; as_of_at:datetime; create_ratio_handoff:bool=True; create_red_flag_handoff:bool=True

class PublicationOut(BaseModel):
    run_id:int; status:str; reporting_period_ids:list[int]; block21_handoff_id:int|None=None; block22_handoff_id:int|None=None

class Block30AStatusCallback(BaseModel):
    requirement_id:int; requirement_group_id:int|None=None; processing_status:str; validation_state:str
    review_required:bool; artifact_id:int|None=None; exact_missing_fields:list[str]=Field(default_factory=list); revision_of_run_id:int|None=None

class Block22AFutureHandoff(BaseModel):
    run_id:int; annual_report_file_ids:list[int]; evidence_ids:list[int]; page_note_references:list[dict[str,Any]]
    extraction_confidence_summary:dict[str,Any]; statement_scope:AccountingScope; periods:list[str]
    validation_summary:ValidationSummaryOut; review_item_ids:list[int]; unmapped_line_ids:list[int]
    approved_workbook_artifact_id:int|None; status:Literal["DEFERRED_NOT_BUILT"]="DEFERRED_NOT_BUILT"

class ExtractionRunPage(BaseModel):
    items:list[ExtractionRunSummaryOut]; total:int; limit:int; offset:int

ExtractionRunDetailOut.model_rebuild()
