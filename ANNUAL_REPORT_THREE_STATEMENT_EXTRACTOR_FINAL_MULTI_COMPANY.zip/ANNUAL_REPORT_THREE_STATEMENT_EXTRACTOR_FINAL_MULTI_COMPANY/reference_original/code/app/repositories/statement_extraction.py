"""SQLAlchemy repository for Block 20A. Transaction ownership stays with services."""
from __future__ import annotations
from datetime import datetime
from sqlalchemy import func,select
from sqlalchemy.orm import Session,selectinload
from app.models.statement_extraction import (
 StatementExtractionRun,StatementExtractionInput,StatementDocumentClassification,StatementSourceEvidence,
 StatementMappingCandidate,StatementNormalizedRow,StatementNormalizedValue,StatementRestatementComparison,
 StatementValidationRun,StatementValidationResult,StatementUnmappedLine,StatementReviewItem,StatementManualCorrection,
 StatementMappingRuleVersion,StatementMappingRule,StatementExtractionArtifact,StatementPublication,
 StatementDownstreamHandoff,StatementExtractionAuditEvent,
)

class StatementExtractionRepository:
    def __init__(self,db:Session):self.db=db
    def add(self,obj):self.db.add(obj);self.db.flush();return obj
    def get_run(self,run_id:int,*,with_inputs:bool=False,with_artifacts:bool=False):
        stmt=select(StatementExtractionRun).where(StatementExtractionRun.id==run_id)
        options=[]
        if with_inputs:options.append(selectinload(StatementExtractionRun.inputs))
        if with_artifacts:options.append(selectinload(StatementExtractionRun.artifacts))
        if options:stmt=stmt.options(*options)
        return self.db.scalar(stmt)
    def get_run_by_uid(self,uid:str):return self.db.scalar(select(StatementExtractionRun).where(StatementExtractionRun.run_uid==uid))
    def next_version(self,instrument_id:int,scope:str)->int:
        value=self.db.scalar(select(func.max(StatementExtractionRun.version_number)).where(StatementExtractionRun.instrument_id==instrument_id,StatementExtractionRun.scope==scope));return int(value or 0)+1
    def list_runs(self,*,instrument_id:int|None=None,status:str|None=None,limit:int=50,offset:int=0):
        stmt=select(StatementExtractionRun);count=select(func.count()).select_from(StatementExtractionRun)
        if instrument_id is not None:stmt=stmt.where(StatementExtractionRun.instrument_id==instrument_id);count=count.where(StatementExtractionRun.instrument_id==instrument_id)
        if status:stmt=stmt.where(StatementExtractionRun.status==status);count=count.where(StatementExtractionRun.status==status)
        stmt=stmt.order_by(StatementExtractionRun.created_at.desc(),StatementExtractionRun.id.desc()).limit(limit).offset(offset)
        return list(self.db.scalars(stmt)),int(self.db.scalar(count) or 0)
    def inputs(self,run_id:int):return list(self.db.scalars(select(StatementExtractionInput).where(StatementExtractionInput.run_id==run_id).order_by(StatementExtractionInput.id)))
    def evidence(self,run_id:int,*,selected:bool|None=None,statement_type:str|None=None):
        stmt=select(StatementSourceEvidence).where(StatementSourceEvidence.run_id==run_id)
        if selected is not None:stmt=stmt.where(StatementSourceEvidence.selected_for_model==selected)
        if statement_type:stmt=stmt.where(StatementSourceEvidence.statement_type==statement_type)
        return list(self.db.scalars(stmt.order_by(StatementSourceEvidence.statement_type,StatementSourceEvidence.financial_year,StatementSourceEvidence.page_number,StatementSourceEvidence.id)))
    def mapping_candidates(self,run_id:int,evidence_id:int|None=None):
        stmt=select(StatementMappingCandidate).where(StatementMappingCandidate.run_id==run_id)
        if evidence_id:stmt=stmt.where(StatementMappingCandidate.evidence_id==evidence_id)
        return list(self.db.scalars(stmt.order_by(StatementMappingCandidate.evidence_id,StatementMappingCandidate.score.desc())))
    def normalized_rows(self,run_id:int):return list(self.db.scalars(select(StatementNormalizedRow).where(StatementNormalizedRow.run_id==run_id).order_by(StatementNormalizedRow.statement_type,StatementNormalizedRow.display_order)))
    def normalized_values(self,run_id:int):return list(self.db.scalars(select(StatementNormalizedValue).where(StatementNormalizedValue.run_id==run_id).order_by(StatementNormalizedValue.financial_year,StatementNormalizedValue.row_id)))
    def validation_results(self,run_id:int):return list(self.db.scalars(select(StatementValidationResult).where(StatementValidationResult.run_id==run_id).order_by(StatementValidationResult.severity,StatementValidationResult.check_id,StatementValidationResult.financial_year)))
    def latest_validation_run(self,run_id:int):return self.db.scalar(select(StatementValidationRun).where(StatementValidationRun.run_id==run_id).order_by(StatementValidationRun.id.desc()).limit(1))
    def review_items(self,run_id:int,*,status:str|None=None):
        stmt=select(StatementReviewItem).where(StatementReviewItem.run_id==run_id)
        if status:stmt=stmt.where(StatementReviewItem.status==status)
        return list(self.db.scalars(stmt.order_by(StatementReviewItem.blocks_final_export.desc(),StatementReviewItem.severity,StatementReviewItem.id)))
    def unmapped_lines(self,run_id:int):return list(self.db.scalars(select(StatementUnmappedLine).where(StatementUnmappedLine.run_id==run_id).order_by(StatementUnmappedLine.materiality,StatementUnmappedLine.id)))
    def restatements(self,run_id:int):return list(self.db.scalars(select(StatementRestatementComparison).where(StatementRestatementComparison.run_id==run_id).order_by(StatementRestatementComparison.financial_year,StatementRestatementComparison.canonical_key)))
    def artifacts(self,run_id:int):return list(self.db.scalars(select(StatementExtractionArtifact).where(StatementExtractionArtifact.run_id==run_id).order_by(StatementExtractionArtifact.generated_at.desc())))
    def get_artifact(self,artifact_id:int):return self.db.get(StatementExtractionArtifact,artifact_id)
    def latest_current_approved(self,instrument_id:int,scope:str):return self.db.scalar(select(StatementExtractionRun).where(StatementExtractionRun.instrument_id==instrument_id,StatementExtractionRun.scope==scope,StatementExtractionRun.is_current_approved.is_(True)).order_by(StatementExtractionRun.version_number.desc()).limit(1))
    def active_mapping_rules(self,version:str|None=None):
        stmt=select(StatementMappingRule).join(StatementMappingRuleVersion).where(StatementMappingRule.is_active.is_(True))
        if version:stmt=stmt.where(StatementMappingRuleVersion.version==version)
        return list(self.db.scalars(stmt))
    def audit(self,run_id:int,event_type:str,message:str,occurred_at:datetime,actor:str|None=None,event_data:dict|None=None):
        return self.add(StatementExtractionAuditEvent(run_id=run_id,event_type=event_type,message=message,occurred_at=occurred_at,actor=actor,event_data=event_data or {}))
