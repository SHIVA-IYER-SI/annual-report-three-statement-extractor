"""Integration ports for existing Kuberpath infrastructure.

The block deliberately does not invent upstream storage, Block 20 publication,
Block 30A completion, or job contracts. Local adapters are supplied only for
CLI testing; production integration must bind real ports.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any,Protocol

@dataclass(frozen=True)
class StoredInput:
    reference:str; processing_path:Path; filename:str; checksum:str; size_bytes:int; mime_type:str|None

class RawVaultPort(Protocol):
    def store(self,path:Path,*,filename:str,mime_type:str|None,metadata:dict[str,Any])->StoredInput:...
    def resolve(self,reference:str)->StoredInput:...

class LocalRawVaultPort:
    """Configurable local adapter for isolated testing, not a second production vault."""
    def __init__(self,root:Path):
        from .security import ensure_within
        self.root=root.resolve();self.root.mkdir(parents=True,exist_ok=True);self._ensure=ensure_within
    def store(self,path:Path,*,filename:str,mime_type:str|None,metadata:dict[str,Any])->StoredInput:
        from .security import safe_filename,sha256_file
        checksum=sha256_file(path);target=self._ensure(self.root,self.root/f"{checksum[:16]}_{safe_filename(filename)}")
        if not target.exists():target.write_bytes(path.read_bytes())
        return StoredInput(target.name,target,safe_filename(filename),checksum,target.stat().st_size,mime_type)
    def resolve(self,reference:str)->StoredInput:
        from .security import sha256_file
        path=self._ensure(self.root,self.root/reference)
        if not path.is_file():raise FileNotFoundError(reference)
        return StoredInput(reference,path,path.name,sha256_file(path),path.stat().st_size,None)

class Block20PublisherPort(Protocol):
    def publish(self,*,run_id:int,instrument_id:int,scope:str,years:list[int],rows:list[dict[str,Any]],as_of_at:datetime,published_by:str)->list[int]:...

class Block30AStatusPort(Protocol):
    def update_processing_status(self,payload:dict[str,Any])->None:...

class DownstreamJobPort(Protocol):
    def enqueue(self,destination:str,payload:dict[str,Any])->str:...

class NullBlock20Publisher:
    def publish(self,**kwargs):raise RuntimeError("Block 20 publication adapter is not configured")
class NullBlock30AStatus:
    def update_processing_status(self,payload):raise RuntimeError("Block 30A callback adapter is not configured")
class NullDownstreamJobs:
    def enqueue(self,destination,payload):raise RuntimeError(f"Downstream job adapter is not configured for {destination}")
