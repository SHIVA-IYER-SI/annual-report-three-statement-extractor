"""Block 20A statement-extraction package.

The orchestration engine is intentionally loaded lazily so deterministic parser,
resource, mapping and workbook modules can be used without importing SQLAlchemy.
"""
from __future__ import annotations
from typing import Any

__all__ = ["StatementExtractionEngine"]

def __getattr__(name: str) -> Any:
    if name == "StatementExtractionEngine":
        from .engine import StatementExtractionEngine
        return StatementExtractionEngine
    raise AttributeError(name)
