"""Deterministic parsing for labels, dates, years, values, units and signs."""
from __future__ import annotations
import re, unicodedata
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Iterable

DASHES={"-","–","—","−","nil","n.a.","na"}
BLANKS={"","none","null"}
UNIT_FACTORS_TO_CRORE={
 "rupee":Decimal("0.0000001"),"rupees":Decimal("0.0000001"),"inr":Decimal("0.0000001"),
 "thousand":Decimal("0.0001"),"thousands":Decimal("0.0001"),"lakh":Decimal("0.01"),"lakhs":Decimal("0.01"),
 "million":Decimal("0.1"),"millions":Decimal("0.1"),"crore":Decimal("1"),"crores":Decimal("1"),
}

@dataclass(frozen=True)
class ParsedNumber:
    value:Decimal|None; status:str; raw:str; explicit_zero:bool=False; ambiguous_dash:bool=False

def normalize_label(value:str)->str:
    text=unicodedata.normalize("NFKC",value).casefold()
    text=re.sub(r"[†‡*#]+"," ",text)
    text=re.sub(r"\b(note|notes)\s*\d+[a-z]?(?:\.\d+)?\b"," ",text)
    text=text.replace("&"," and ")
    text=re.sub(r"[^a-z0-9%]+"," ",text)
    return " ".join(text.split())

def parse_number(value:object,dash_means_zero:bool|None=None,expense_as_positive:bool=False)->ParsedNumber:
    if value is None: return ParsedNumber(None,"MISSING_NOT_DISCLOSED","")
    raw=str(value).strip(); lowered=raw.casefold()
    if lowered in BLANKS: return ParsedNumber(None,"MISSING_NOT_DISCLOSED",raw)
    if lowered in DASHES:
        if dash_means_zero is True or lowered=="nil": return ParsedNumber(Decimal(0),"DISCLOSED_ZERO",raw,True)
        return ParsedNumber(None,"AMBIGUOUS_REVIEW_REQUIRED",raw,False,True)
    negative=False
    if raw.startswith("(") and raw.endswith(")"): negative=True; raw=raw[1:-1]
    raw=raw.replace("₹","").replace("Rs.","").replace("Rs","").replace(",","").replace(" ","")
    raw=raw.replace("−","-").replace("–","-")
    if raw.endswith("-"): negative=True; raw=raw[:-1]
    try: number=Decimal(raw)
    except InvalidOperation: return ParsedNumber(None,"AMBIGUOUS_REVIEW_REQUIRED",str(value))
    if negative: number=-abs(number)
    if expense_as_positive: number=abs(number)
    return ParsedNumber(number,"DISCLOSED_ZERO" if number==0 else "REPORTED",str(value),number==0)

def detect_unit(text:str)->str|None:
    n=normalize_label(text)
    patterns=[(r"\b(in|amounts? in|figures? in)\s+crores?\b","crore"),(r"\bmillions?\b","million"),(r"\blakhs?\b","lakh"),(r"\bthousands?\b","thousand"),(r"\brupees?\b|\binr\b","rupee")]
    for pattern,unit in patterns:
        if re.search(pattern,n): return unit
    return None

def factor_to_crore(unit:str|None)->Decimal|None:
    return UNIT_FACTORS_TO_CRORE.get(normalize_label(unit or ""))

def normalize_to_crore(value:Decimal|None,unit:str|None)->Decimal|None:
    if value is None: return None
    factor=factor_to_crore(unit)
    return value*factor if factor is not None else None

def parse_financial_year(text:str)->int|None:
    patterns=[r"\bfy\s*['-]?(\d{2,4})\b",r"year ended\s+(?:31\s+march\s+)?(20\d{2})",r"\b(20\d{2})\s*[-/]\s*(?:20)?\d{2}\b"]
    for pattern in patterns:
        m=re.search(pattern,text,re.I)
        if m:
            year=int(m.group(1)); return 2000+year if year<100 else year
    return None

def extract_year_headers(cells:Iterable[object])->list[int]:
    years=[]
    for cell in cells:
        y=parse_financial_year(str(cell or ""))
        if y and y not in years: years.append(y)
    return years

def parse_period_end(text:str)->date|None:
    y=parse_financial_year(text)
    if not y:return None
    if re.search(r"march",text,re.I): return date(y,3,31)
    return date(y,3,31)

def detect_currency(text:str)->str|None:
    if re.search(r"₹|\bINR\b|Indian rupees?",text,re.I): return "INR"
    if re.search(r"\bUSD\b|US\$",text,re.I): return "USD"
    if re.search(r"\bEUR\b|€",text,re.I): return "EUR"
    if re.search(r"\bGBP\b|£",text,re.I): return "GBP"
    return None
