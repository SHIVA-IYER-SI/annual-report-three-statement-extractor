"""Workbook and auxiliary artifact generation using a storage abstraction."""
from __future__ import annotations
import csv,hashlib,json,zipfile
from dataclasses import asdict,is_dataclass
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
from typing import Any,Protocol
from .security import ensure_within,safe_filename,sha256_file
from .workbook import build_workbook,assert_workbook_contract

EXCEL_MIME="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
class ArtifactStorage(Protocol):
    def put(self,source:Path,key:str)->str:...
    def resolve(self,reference:str)->Path:...
class FileSystemArtifactStorage:
    def __init__(self,root:Path):self.root=root.resolve();self.root.mkdir(parents=True,exist_ok=True)
    def put(self,source:Path,key:str)->str:
        target=ensure_within(self.root,self.root/safe_filename(key));target.write_bytes(source.read_bytes());return target.name
    def resolve(self,reference:str)->Path:return ensure_within(self.root,self.root/reference)

def _json_default(value):
    if isinstance(value,Decimal):return str(value)
    if isinstance(value,(datetime,)):return value.isoformat()
    if is_dataclass(value):return asdict(value)
    raise TypeError(type(value).__name__)

def deterministic_workbook_filename(company:str,scope:str,years:list[int],version:str,review:bool=False)->str:
    first=min(years);last=max(years);base=f"{safe_filename(company).replace(' ','_')}_Historical_3_Statement_{scope.title()}_FY{first}_FY{last}_v{safe_filename(version)}"
    return base+("_REVIEW_REQUIRED" if review else "")+".xlsx"

def write_csv(path:Path,rows:list[dict[str,Any]],headers:list[str]|None=None):
    if headers is None:headers=sorted({k for r in rows for k in r}) if rows else []
    with path.open("w",newline="",encoding="utf-8-sig") as fh:
        w=csv.DictWriter(fh,fieldnames=headers,extrasaction="ignore");w.writeheader();w.writerows(rows)

def generate_artifact_files(*,workdir:Path,company:str,scope:str,years:list[int],version:str,payload:dict[str,Any],validation_summary:dict[str,Any],extracted_data:dict[str,Any],evidence:list[dict[str,Any]],validation_results:list[dict[str,Any]],unmapped:list[dict[str,Any]],reviews:list[dict[str,Any]],restatements:list[dict[str,Any]],export_eligible:bool)->dict[str,Path]:
    workdir.mkdir(parents=True,exist_ok=True);review=not export_eligible
    workbook_name=deterministic_workbook_filename(company,scope,years,version,review=review);workbook_path=workdir/workbook_name
    wb=build_workbook(payload,review_required=review);wb.save(workbook_path)
    errors=assert_workbook_contract(workbook_path)
    if errors:raise ValueError("workbook contract failed: "+";".join(errors))
    paths={"FINAL_WORKBOOK" if export_eligible else "REVIEW_WORKBOOK":workbook_path}
    json_path=workdir/"extracted_data.json";json_path.write_text(json.dumps(extracted_data,indent=2,default=_json_default),encoding="utf-8");paths["EXTRACTED_DATA_JSON"]=json_path
    validation_path=workdir/"validation_report.json";validation_path.write_text(json.dumps({"summary":validation_summary,"results":validation_results},indent=2,default=_json_default),encoding="utf-8");paths["VALIDATION_REPORT"]=validation_path
    for key,name,rows in [("SOURCE_EVIDENCE","source_evidence.csv",evidence),("UNMAPPED_LINES","unmapped_lines.csv",unmapped),("MANUAL_REVIEW","manual_review.csv",reviews),("RESTATEMENT_COMPARISON","restatement_comparison.csv",restatements)]:
        p=workdir/name;write_csv(p,rows);paths[key]=p
    audit=workdir/"audit_pack.zip"
    with zipfile.ZipFile(audit,"w",zipfile.ZIP_DEFLATED) as z:
        for key,p in paths.items():z.write(p,p.name)
        z.writestr("generation_metadata.json",json.dumps({"company":company,"scope":scope,"years":years,"version":version,"generated_at":datetime.now(timezone.utc).isoformat(),"export_eligible":export_eligible,"files":{k:{"filename":p.name,"sha256":sha256_file(p),"bytes":p.stat().st_size} for k,p in paths.items()}},indent=2))
    paths["AUDIT_PACK"]=audit
    return paths
