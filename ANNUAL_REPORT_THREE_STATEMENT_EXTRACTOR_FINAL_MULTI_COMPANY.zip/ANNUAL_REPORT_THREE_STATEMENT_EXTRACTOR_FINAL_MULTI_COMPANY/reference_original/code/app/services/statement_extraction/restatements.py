"""Point-in-time duplicate-year/restatement selection."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date,datetime
from decimal import Decimal
from typing import Iterable

@dataclass
class RestatementCandidate:
    evidence_id:int; financial_year:int; canonical_key:str; normalized_value:Decimal|None; publication_date:date|None
    extracted_at:datetime; is_explicitly_restated:bool; source_file:str
@dataclass
class RestatementDecision:
    selected:RestatementCandidate; superseded:list[RestatementCandidate]; difference:Decimal|None; is_restated:bool; explanation:str

def resolve(candidates:Iterable[RestatementCandidate],tolerance:Decimal=Decimal("0.01"))->RestatementDecision:
    items=list(candidates)
    if not items:raise ValueError("at least one candidate is required")
    items.sort(key=lambda c:(c.publication_date or date.min,c.extracted_at,c.evidence_id))
    selected=items[-1]; superseded=items[:-1]
    diffs=[abs((selected.normalized_value or Decimal(0))-(c.normalized_value or Decimal(0))) for c in superseded if selected.normalized_value is not None and c.normalized_value is not None]
    difference=max(diffs,default=None)
    explicit=selected.is_explicitly_restated
    restated=explicit or (difference is not None and difference>tolerance)
    explanation=("Latest published comparative selected; source explicitly identifies a restatement." if explicit else
                 "Latest published comparative selected; normalized values differ beyond tolerance." if restated else
                 "Duplicate evidence agrees within tolerance; latest published source selected.")
    return RestatementDecision(selected,superseded,difference,restated,explanation)
