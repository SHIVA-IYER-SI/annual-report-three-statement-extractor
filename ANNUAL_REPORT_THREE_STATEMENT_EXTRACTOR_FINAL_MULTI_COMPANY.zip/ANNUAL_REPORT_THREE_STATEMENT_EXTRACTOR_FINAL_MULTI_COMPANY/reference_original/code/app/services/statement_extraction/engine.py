"""Block 20A orchestration service.

The engine is usable synchronously for local TCS testing and exposes the same
steps for later worker integration. It never publishes unresolved draft data to
Block 20 and never marks Block 30A processing complete on upload alone.
"""
from __future__ import annotations
import json,os,tempfile,uuid
from dataclasses import asdict
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
from typing import Any
from sqlalchemy.orm import Session

from app.models.statement_extraction import *
from app.repositories.statement_extraction import StatementExtractionRepository
from app.schemas.statement_extraction import CreateExtractionRunRequest,CorrectionRequest,RerunRequest
from .artifacts import ArtifactStorage,FileSystemArtifactStorage,generate_artifact_files
from .assembly import DynamicStatementAssembler,SelectedValue,workbook_payload
from .detection import classify_text_document
from .mapping import CanonicalMapper
from .ocr import DisabledOCRAdapter,OCRAdapter
from .parsing import detect_currency,detect_unit,factor_to_crore,normalize_to_crore,parse_number
from .pdf_native import NativePDFExtractor,PDFDependencyMissing
from .ports import Block20PublisherPort,Block30AStatusPort,DownstreamJobPort,NullBlock20Publisher,NullBlock30AStatus,NullDownstreamJobs,RawVaultPort,LocalRawVaultPort
from .resources import verify_runtime_resources
from .restatements import RestatementCandidate,resolve
from .security import safe_filename,sha256_file,validate_input_file
from .validation import StatementValidator
from .workbook import assert_workbook_contract
from .xbrl import parse_xbrl

ENGINE_VERSION="20A.1.0";MAPPING_VERSION="blueprint-1.0";VALIDATION_VERSION="blueprint-1.0";WORKBOOK_VERSION="blueprint-1.0"

class ExtractionError(RuntimeError):pass
class ExtractionNotFound(ExtractionError):pass
class DependencyMissing(ExtractionError):pass
class ExportBlocked(ExtractionError):pass

class StatementExtractionEngine:
    def __init__(self,db:Session,*,raw_vault:RawVaultPort|None=None,artifact_storage:ArtifactStorage|None=None,block20:Block20PublisherPort|None=None,block30a:Block30AStatusPort|None=None,jobs:DownstreamJobPort|None=None,ocr:OCRAdapter|None=None):
        self.db=db;self.repo=StatementExtractionRepository(db)
        base=Path(os.getenv("KUBERPATH_LOCAL_STORAGE_DIR",tempfile.gettempdir()))/"kuberpath_statement_extraction"
        self.raw_vault=raw_vault or LocalRawVaultPort(base/"raw-vault")
        self.artifacts=artifact_storage or FileSystemArtifactStorage(base/"artifacts")
        self.block20=block20 or NullBlock20Publisher();self.block30a=block30a or NullBlock30AStatus();self.jobs=jobs or NullDownstreamJobs();self.ocr=ocr or DisabledOCRAdapter()
        resource_errors=verify_runtime_resources()
        if resource_errors:raise DependencyMissing("Blueprint resource integrity failed: "+",".join(resource_errors))
    def create_run(self,request:CreateExtractionRunRequest,now:datetime|None=None)->StatementExtractionRun:
        now=now or datetime.now(timezone.utc);version=self.repo.next_version(request.instrument_id,request.scope.value)
        run=self.repo.add(StatementExtractionRun(run_uid=str(uuid.uuid4()),instrument_id=request.instrument_id,company_name=request.company_name,scope=request.scope.value,output_currency=request.output_currency,output_unit=request.output_unit,selected_years=[str(y) for y in sorted(request.selected_years)],status=ExtractionRunStatus.CREATED,review_required=False,extraction_engine_version=ENGINE_VERSION,mapping_rule_version=MAPPING_VERSION,validation_rule_version=VALIDATION_VERSION,workbook_format_version=WORKBOOK_VERSION,version_number=version,details={"latest_restated_comparative":request.latest_restated_comparative,"output_version_label":request.output_version_label}))
        for ref in request.inputs:
            filename=safe_filename(ref.original_filename)
            self.repo.add(StatementExtractionInput(run_id=run.id,requirement_id=ref.requirement_id,requirement_group_id=ref.requirement_group_id,source_id=ref.source_id,raw_vault_reference=ref.raw_vault_reference,original_filename=ref.original_filename,safe_filename=filename,mime_type=ref.mime_type,size_bytes=ref.size_bytes,checksum=ref.checksum,source_url=ref.source_url,local_processing_reference=ref.local_processing_reference,input_metadata=ref.metadata))
        run.status=ExtractionRunStatus.FILES_REGISTERED;self.repo.audit(run.id,"RUN_CREATED","Extraction run and inputs registered",now,event_data={"input_count":len(request.inputs)});self.db.commit();return run
    def run_sync(self,run_id:int,now:datetime|None=None)->StatementExtractionRun:
        now=now or datetime.now(timezone.utc);run=self.repo.get_run(run_id,with_inputs=True)
        if not run:raise ExtractionNotFound(f"run {run_id} not found")
        run.started_at=now
        try:
            self._set(run,ExtractionRunStatus.CLASSIFYING_DOCUMENTS,"Classifying documents",now);self._extract_inputs(run,now)
            self._set(run,ExtractionRunStatus.NORMALIZING,"Generating canonical mapping candidates",now);self._map_evidence(run,now)
            self._set(run,ExtractionRunStatus.RESOLVING_RESTATEMENTS,"Resolving duplicate years/restatements",now);self._resolve_restatements(run,now)
            self._set(run,ExtractionRunStatus.ASSEMBLING_MODEL,"Assembling dynamic statements",now);payload,assembled,selected,years=self._assemble(run)
            self._set(run,ExtractionRunStatus.VALIDATING,"Running validations",now);summary=self._validate(run,assembled,selected,years,now)
            self._generate_artifacts(run,payload,assembled,selected,summary,years,now)
            run.review_required=not summary.export_eligible;run.status=ExtractionRunStatus.REVIEW_REQUIRED if run.review_required else ExtractionRunStatus.EXPORT_READY
            if not run.review_required:run.completed_at=now
            self._notify_30a(run,summary)
            self.repo.audit(run.id,"RUN_FINISHED","Extraction run reached review/export state",now,event_data={"status":run.status,"export_eligible":summary.export_eligible})
            self.db.commit();return run
        except Exception as exc:
            self.db.rollback();run=self.repo.get_run(run_id)
            if run:
                run.status=ExtractionRunStatus.FAILED;run.failure_code=type(exc).__name__;run.failure_reason=str(exc)[:4000];run.completed_at=now;self.db.commit()
            raise
    def _set(self,run,status,message,now):run.status=status;self.repo.audit(run.id,"PROGRESS",message,now,event_data={"status":status});self.db.flush()
    def _path_for_input(self,item:StatementExtractionInput)->Path:
        if item.local_processing_reference:
            path=Path(item.local_processing_reference);issues=validate_input_file(path,item.mime_type)
            if issues:raise ExtractionError(f"input {item.id} invalid: {issues}")
            if sha256_file(path)!=item.checksum:raise ExtractionError(f"input {item.id} checksum mismatch")
            return path
        if item.raw_vault_reference:return self.raw_vault.resolve(item.raw_vault_reference).processing_path
        raise DependencyMissing(f"input {item.id} has no resolvable file reference")
    def _extract_inputs(self,run,now):
        mapper_version=run.mapping_rule_version
        for item in run.inputs:
            path=self._path_for_input(item);suffix=path.suffix.lower()
            if suffix==".pdf":
                try:result=NativePDFExtractor().extract(path)
                except PDFDependencyMissing as exc:raise DependencyMissing(str(exc)) from exc
                classification=classify_text_document(path,result.page_texts,result.scanned_pages)
                if result.scanned_pages and self.ocr.available():
                    ocr_results=self.ocr.extract_pages(path,result.scanned_pages)
                    low=[r.page_number for r in ocr_results if r.confidence is None or r.confidence<0.85]
                    if low:self._review(run.id,None,"LOW_CONFIDENCE_OCR","CRITICAL",f"Low OCR confidence on material candidate pages {low}",True)
                elif result.scanned_pages:
                    self._review(run.id,None,"OCR_REQUIRED","CRITICAL",f"Scanned/image-dominant pages detected but OCR is not configured: {result.scanned_pages}",True)
                self._save_classification(item,classification)
                for row in result.rows:
                    for year,raw in row.values.items():
                        parsed=parse_number(raw,dash_means_zero=None,expense_as_positive=(row.statement_type=="INCOME_STATEMENT" and "expense" in row.original_label.casefold()))
                        factor=factor_to_crore(row.unit);normalized=normalize_to_crore(parsed.value,row.unit)
                        review=parsed.status=="AMBIGUOUS_REVIEW_REQUIRED" or factor is None
                        evidence=self.repo.add(StatementSourceEvidence(run_id=run.id,input_id=item.id,instrument_id=run.instrument_id,source_id=item.source_id,accounting_scope=row.scope,financial_year=year,period_end=None,statement_type=row.statement_type,note_number=None,table_title=None,parent_label=None,original_label=row.original_label,original_value_text=None if raw is None else str(raw),original_value_numeric=parsed.value,original_currency=classification.currency or "INR",original_unit=row.unit,scale_factor_to_crore=factor,normalized_value=normalized,value_status=parsed.status,page_number=row.page_number,bounding_box=row.bbox,source_snippet=" | ".join(str(c) for c in row.raw_cells),extraction_method="PDF_NATIVE_TABLE",extraction_confidence=Decimal(str(row.confidence)),canonical_key=None,mapping_confidence=None,selected_for_model=False,review_note="UNIT_UNRESOLVED" if factor is None else None,extracted_at=now,evidence_metadata={"table_index":row.table_index,"row_index":row.row_index,"period_type":"INTERIM" if classification.document_type=="QUARTERLY_RESULTS" else "ANNUAL","document_type":classification.document_type}))
                        if review:self._review(run.id,evidence.id,"EXTRACTION_AMBIGUITY","CRITICAL" if factor is None else "ERROR",f"Ambiguous value or unit for {row.original_label} FY{year}",True)
            elif suffix in {".xml",".xhtml",".html",".htm"}:
                result=parse_xbrl(path);texts=[];classification=classify_text_document(path,texts,[],result.kind);self._save_classification(item,classification)
                for fact in result.facts:
                    ctx=result.contexts.get(fact.context_id or "");year=(ctx.instant or ctx.end_date).year if ctx and (ctx.instant or ctx.end_date) else None
                    unit_text=result.units.get(fact.unit_id or "","");unit=detect_unit(unit_text) or ("rupee" if "INR" in unit_text.upper() else None);factor=factor_to_crore(unit);normalized=normalize_to_crore(fact.numeric_value,unit)
                    self.repo.add(StatementSourceEvidence(run_id=run.id,input_id=item.id,instrument_id=run.instrument_id,source_id=item.source_id,accounting_scope=classification.scope,financial_year=year,period_start=ctx.start_date if ctx else None,period_end=(ctx.instant or ctx.end_date) if ctx else None,statement_type="OTHER",original_label=fact.concept,original_value_text=fact.raw_value,original_value_numeric=fact.numeric_value,original_currency="INR" if "INR" in unit_text.upper() else None,original_unit=unit,scale_factor_to_crore=factor,normalized_value=normalized,value_status="MISSING_NOT_DISCLOSED" if fact.nil else "REPORTED",page_number=None,bounding_box={},source_snippet=None,extraction_method=result.kind,extraction_confidence=Decimal("0.90"),xbrl_concept=fact.concept,xbrl_context_id=fact.context_id,xbrl_unit_id=fact.unit_id,xbrl_decimals=fact.decimals,canonical_key=None,mapping_confidence=None,selected_for_model=False,extracted_at=now,evidence_metadata={"context":asdict(ctx) if ctx else None,"attributes":fact.attributes,"period_type":("ANNUAL" if (ctx and ((ctx.instant is not None) or (ctx.start_date and ctx.end_date and (ctx.end_date-ctx.start_date).days>=300))) else "INTERIM")}))
            else:raise ExtractionError(f"unsupported input type: {path.suffix}")
    def _save_classification(self,item,c):
        row=StatementDocumentClassification(input_id=item.id,document_type=c.document_type,company_name_detected=c.company_name,financial_year=c.financial_year,scope=c.scope,available_scopes=c.available_scopes,currency=c.currency,reporting_unit=c.reporting_unit,page_count=c.page_count,native_pdf=c.native_pdf,scanned_pages=c.scanned_pages,xbrl_kind=c.xbrl_kind,is_revision=False,classification_confidence=Decimal(str(c.confidence)),review_required_reason=c.review_reason,classification_metadata={})
        self.repo.add(row)
    def _map_evidence(self,run,now):
        rules=[{"statement_type":r.statement_type,"original_label":r.original_label,"parent_context":r.parent_context,"canonical_key":r.canonical_key} for r in self.repo.active_mapping_rules(run.mapping_rule_version)]
        mapper=CanonicalMapper(rules)
        for evidence in self.repo.evidence(run.id):
            period_type=(evidence.evidence_metadata or {}).get("period_type","ANNUAL")
            if period_type!="ANNUAL":
                self.repo.add(StatementUnmappedLine(run_id=run.id,evidence_id=evidence.id,candidate_keys=[],confidence=evidence.extraction_confidence,reason_not_selected="INTERIM_EXCLUDED_FROM_ANNUAL_WORKBOOK",materiality="NOT_APPLICABLE",review_status="RESOLVED"))
                continue
            if evidence.accounting_scope not in {run.scope}:
                reason="SCOPE_NOT_SELECTED" if evidence.accounting_scope in {"CONSOLIDATED","STANDALONE"} else "SCOPE_AMBIGUOUS_REVIEW_REQUIRED"
                self.repo.add(StatementUnmappedLine(run_id=run.id,evidence_id=evidence.id,candidate_keys=[],confidence=evidence.extraction_confidence,reason_not_selected=reason,materiality="NOT_APPLICABLE" if reason=="SCOPE_NOT_SELECTED" else "MATERIAL",review_status="RESOLVED" if reason=="SCOPE_NOT_SELECTED" else "OPEN"))
                if reason=="SCOPE_AMBIGUOUS_REVIEW_REQUIRED":self._review(run.id,evidence.id,"SCOPE_REVIEW","CRITICAL",f"Accounting scope unresolved for '{evidence.original_label}'",True)
                continue
            # XBRL concept remains source label; statement inference uses concept keywords as baseline.
            statement=evidence.statement_type
            if statement=="OTHER":statement=self._infer_statement_from_label(evidence.original_label)
            candidates=mapper.candidates(statement,evidence.original_label,evidence.parent_label,evidence.table_title,{"scope":evidence.accounting_scope})
            for index,c in enumerate(candidates):self.repo.add(StatementMappingCandidate(run_id=run.id,evidence_id=evidence.id,canonical_key=c.canonical_key,score=Decimal(str(c.score)),confidence=Decimal(str(c.confidence)),reasons=list(c.reasons),selected=False,mapping_rule_version=run.mapping_rule_version))
            need_review=mapper.needs_mandatory_review(evidence.original_label,candidates," ".join(filter(None,[evidence.parent_label,evidence.table_title])))
            if candidates and not need_review:
                best=candidates[0];evidence.canonical_key=best.canonical_key;evidence.mapping_confidence=Decimal(str(best.confidence));evidence.statement_type=statement;evidence.selected_for_model=True
                db_candidates=self.repo.mapping_candidates(run.id,evidence.id)
                for row in db_candidates:
                    if row.canonical_key==best.canonical_key:row.selected=True
            else:
                evidence.value_status="AMBIGUOUS_REVIEW_REQUIRED";evidence.review_note="CANONICAL_MAPPING_REVIEW_REQUIRED"
                self.repo.add(StatementUnmappedLine(run_id=run.id,evidence_id=evidence.id,candidate_keys=[{"canonical_key":c.canonical_key,"score":c.score} for c in candidates],confidence=Decimal(str(candidates[0].confidence)) if candidates else None,reason_not_selected="AMBIGUOUS_MAPPING" if candidates else "NO_MAPPING_CANDIDATE",materiality="MATERIAL" if evidence.normalized_value not in {None,Decimal(0)} else "UNKNOWN",review_status="OPEN"))
                self._review(run.id,evidence.id,"MAPPING_REVIEW","CRITICAL" if evidence.normalized_value not in {None,Decimal(0)} else "WARNING",f"Canonical mapping unresolved for '{evidence.original_label}'",True)
    def _infer_statement_from_label(self,label):
        n=label.casefold()
        if any(x in n for x in ("cash flow","net cash","cash generated")):return "CASH_FLOW_STATEMENT"
        if any(x in n for x in ("asset","liabilit","equity","receivable","payable","inventory")):return "BALANCE_SHEET"
        return "INCOME_STATEMENT"
    def _resolve_restatements(self,run,now):
        groups={}
        inputs={i.id:i for i in self.repo.inputs(run.id)}
        for e in self.repo.evidence(run.id,selected=True):
            if e.canonical_key and e.financial_year:groups.setdefault((e.financial_year,e.canonical_key),[]).append(e)
        for (year,key),items in groups.items():
            if len(items)<2:continue
            candidates=[]
            for e in items:
                inp=inputs[e.input_id];pub=inp.classification.publication_date if inp.classification else None
                candidates.append(RestatementCandidate(e.id,year,key,e.normalized_value,pub,e.extracted_at,bool(inp.classification and inp.classification.is_revision),inp.original_filename))
            decision=resolve(candidates)
            for e in items:
                e.selected_for_model=e.id==decision.selected.evidence_id
                if not e.selected_for_model:e.value_status="SUPERSEDED_COMPARATIVE"
                elif decision.is_restated:e.value_status="REPORTED_RESTATED"
            self.repo.add(StatementRestatementComparison(run_id=run.id,financial_year=year,canonical_key=key,older_evidence_id=decision.superseded[-1].evidence_id,later_evidence_id=decision.selected.evidence_id,older_value=decision.superseded[-1].normalized_value,later_value=decision.selected.normalized_value,difference=decision.difference,selected_evidence_id=decision.selected.evidence_id,is_restated=decision.is_restated,explanation=decision.explanation))
    def _assemble(self,run):
        evidence=self.repo.evidence(run.id,selected=True);years=sorted({e.financial_year for e in evidence if e.financial_year and (not run.selected_years or str(e.financial_year) in run.selected_years)})
        if not years:raise ExportBlocked("No reliable annual financial years are available")
        selected=[SelectedValue(e.id,e.statement_type,e.canonical_key,e.financial_year,e.normalized_value,e.value_status,{"source_file":next((i.original_filename for i in run.inputs if i.id==e.input_id),None),"page":e.page_number,"note_number":e.note_number,"original_label":e.original_label,"status":e.value_status}) for e in evidence if e.canonical_key and e.financial_year in years]
        assembled=DynamicStatementAssembler().assemble(selected,years);payload=workbook_payload(run.company_name,run.scope,years,assembled)
        # replace persisted normalized staging for rerun determinism
        for statement,rows in assembled.items():
            for row in rows:
                dbrow=self.repo.add(StatementNormalizedRow(run_id=run.id,statement_type=statement,canonical_key=row.key,display_label=row.label,parent_key=row.parent_key,hierarchy_level=row.hierarchy_level,row_type=row.row_type,value_type=row.value_type,display_order=row.display_order,formula_definition=row.formulas,inclusion_reason=row.inclusion_reason,blank_after=row.blank_after))
                for year in years:
                    y=f"FY{str(year)[-2:]}";self.repo.add(StatementNormalizedValue(run_id=run.id,row_id=dbrow.id,financial_year=year,value=row.values.get(y),value_status=row.statuses.get(y,"MISSING_NOT_DISCLOSED"),evidence_id=row.evidence_ids.get(y),formula_definition=row.formulas.get(y,{})))
        return payload,assembled,selected,years
    def _validate(self,run,assembled,selected,years,now):
        restatement_conflicts=0;material_unmapped=sum(1 for x in self.repo.unmapped_lines(run.id) if x.materiality=="MATERIAL" and x.review_status=="OPEN");reviews=self.repo.review_items(run.id,status="OPEN");blocking=sum(1 for x in reviews if x.blocks_final_export)
        summary=StatementValidator().validate(scope_values={run.scope},units={"INR_CRORE"},selected_values=selected,assembled=assembled,years=years,restatement_conflicts=restatement_conflicts,material_unmapped=material_unmapped,open_blocking_reviews=blocking)
        vr=self.repo.add(StatementValidationRun(run_id=run.id,version=run.validation_rule_version,started_at=now,completed_at=now,critical_count=summary.critical_count,error_count=summary.error_count,warning_count=summary.warning_count,passed_count=summary.passed_count,export_eligible=summary.export_eligible))
        for f in summary.findings:self.repo.add(StatementValidationResult(run_id=run.id,validation_run_id=vr.id,check_id=f.check_id,check_name=f.check_name,statement_type=f.statement_type,financial_year=f.financial_year,severity=f.severity,outcome=f.outcome,observed_value=f.observed,expected_value=f.expected,difference=f.difference,tolerance=f.tolerance,message=f.message,evidence_ids=f.evidence_ids,details=f.details))
        return summary
    def _generate_artifacts(self,run,payload,assembled,selected,summary,years,now):
        workdir=Path(tempfile.mkdtemp(prefix=f"kuberpath_20a_{run.id}_"))
        evidence_rows=[self._model_dict(e) for e in self.repo.evidence(run.id)];validations=[self._model_dict(v) for v in self.repo.validation_results(run.id)];unmapped=[self._model_dict(v) for v in self.repo.unmapped_lines(run.id)];reviews=[self._model_dict(v) for v in self.repo.review_items(run.id)];restatements=[self._model_dict(v) for v in self.repo.restatements(run.id)]
        summary_dict={"critical_count":summary.critical_count,"error_count":summary.error_count,"warning_count":summary.warning_count,"passed_count":summary.passed_count,"export_eligible":summary.export_eligible}
        paths=generate_artifact_files(workdir=workdir,company=run.company_name,scope=run.scope,years=years,version=str(run.version_number),payload=payload,validation_summary=summary_dict,extracted_data={"run_id":run.id,"company":run.company_name,"scope":run.scope,"years":years,"payload":payload},evidence=evidence_rows,validation_results=validations,unmapped=unmapped,reviews=reviews,restatements=restatements,export_eligible=summary.export_eligible)
        for artifact_type,path in paths.items():
            ref=self.artifacts.put(path,path.name);is_workbook=artifact_type in {"FINAL_WORKBOOK","REVIEW_WORKBOOK"}
            self.repo.add(StatementExtractionArtifact(artifact_uid=str(uuid.uuid4()),run_id=run.id,artifact_type=artifact_type,filename=path.name,mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if is_workbook else ("application/zip" if artifact_type=="AUDIT_PACK" else "application/json" if path.suffix==".json" else "text/csv"),size_bytes=path.stat().st_size,checksum=sha256_file(path),storage_reference=ref,status="READY" if summary.export_eligible or artifact_type!="FINAL_WORKBOOK" else "REVIEW_REQUIRED",version=str(run.version_number),generated_at=now,critical_error_count=summary.critical_count,warning_count=summary.warning_count,review_required=not summary.export_eligible,download_available=(artifact_type!="FINAL_WORKBOOK" or summary.export_eligible),preview_available=is_workbook,artifact_metadata={"years":years,"scope":run.scope,"validation":summary_dict}))
    def _notify_30a(self,run,summary):
        requirement_ids=[i.requirement_id for i in self.repo.inputs(run.id) if i.requirement_id]
        for rid in requirement_ids:
            payload={"requirement_id":rid,"processing_status":"VALIDATED" if summary.export_eligible else "REVIEW_REQUIRED","validation_state":"PASSED" if summary.export_eligible else "REVIEW_REQUIRED","review_required":not summary.export_eligible,"exact_missing_fields":[f.message for f in summary.findings if f.outcome=="FAIL"]}
            try:self.block30a.update_processing_status(payload)
            except RuntimeError:self.repo.add(StatementDownstreamHandoff(run_id=run.id,destination="BLOCK_30A",status="PENDING",payload=payload,created_at_business=datetime.now(timezone.utc)))
    def _review(self,run_id,evidence_id,item_type,severity,reason,blocks):
        return self.repo.add(StatementReviewItem(run_id=run_id,evidence_id=evidence_id,item_type=item_type,severity=severity,status="OPEN",reason=reason,recommended_action="Inspect source page/table, correct metadata or mapping, then rerun.",blocks_final_export=blocks,resolution={}))
    def apply_correction(self,run_id:int,review_item_id:int,request:CorrectionRequest,now:datetime|None=None):
        now=now or datetime.now(timezone.utc);run=self.repo.get_run(run_id);item=self.db.get(StatementReviewItem,review_item_id)
        if not run or not item or item.run_id!=run_id:raise ExtractionNotFound("run/review item not found")
        if item.status!="OPEN":raise ExtractionError("review item is not open")
        evidence=self.db.get(StatementSourceEvidence,item.evidence_id) if item.evidence_id else None;before=self._model_dict(evidence) if evidence else {}
        after={"action":request.action,"canonical_key":request.canonical_key,"corrected_value":str(request.corrected_value) if request.corrected_value is not None else None,"corrected_unit":request.corrected_unit,"corrected_year":request.corrected_year,"corrected_scope":request.corrected_scope.value if request.corrected_scope else None,"context":request.context}
        if evidence:
            if request.action in {"CONFIRM_MAPPING","SELECT_CANONICAL_KEY"} and request.canonical_key:evidence.canonical_key=request.canonical_key;evidence.selected_for_model=True;evidence.value_status="REPORTED"
            if request.action=="CORRECT_VALUE":evidence.normalized_value=request.corrected_value
            if request.action=="CORRECT_SIGN" and evidence.normalized_value is not None:evidence.normalized_value=-evidence.normalized_value
            if request.action=="CORRECT_UNIT":evidence.original_unit=request.corrected_unit;evidence.scale_factor_to_crore=factor_to_crore(request.corrected_unit);evidence.normalized_value=normalize_to_crore(evidence.original_value_numeric,request.corrected_unit)
            if request.action=="CORRECT_YEAR":evidence.financial_year=request.corrected_year
            if request.action=="CORRECT_SCOPE" and request.corrected_scope:evidence.accounting_scope=request.corrected_scope.value
            if request.action=="CLASSIFY_DISCLOSED_ZERO":evidence.normalized_value=Decimal(0);evidence.value_status="DISCLOSED_ZERO"
            if request.action=="CLASSIFY_MISSING":evidence.normalized_value=None;evidence.value_status="MISSING_NOT_DISCLOSED";evidence.selected_for_model=False
            if request.action=="MARK_SUPERSEDED":evidence.value_status="SUPERSEDED_COMPARATIVE";evidence.selected_for_model=False
            if request.action in {"MARK_DUPLICATE","EXCLUDE_NARRATIVE"}:evidence.selected_for_model=False
            if request.action=="APPROVE_RESIDUAL":evidence.value_status="CALCULATED_RESIDUAL";evidence.evidence_metadata={**evidence.evidence_metadata,"review_approved":True,"approval_reason":request.reason}
        correction=self.repo.add(StatementManualCorrection(run_id=run_id,review_item_id=item.id,evidence_id=item.evidence_id,correction_scope=request.correction_scope.value,action=request.action,before_state=before,after_state=after,reason=request.reason,corrected_by=request.corrected_by,corrected_at=now))
        if request.correction_scope!="RUN_ONLY" and evidence and request.canonical_key:
            version=self._new_mapping_version(run.mapping_rule_version,request.corrected_by,request.reason,now)
            rule=self.repo.add(StatementMappingRule(version_id=version.id,rule_uid=str(uuid.uuid4()),correction_scope=request.correction_scope.value,company_instrument_id=run.instrument_id if request.correction_scope=="COMPANY_OR_REPORT_TEMPLATE" else None,report_template_fingerprint=request.company_template_fingerprint,statement_type=evidence.statement_type,original_label=evidence.original_label,normalized_label=evidence.original_label.casefold(),parent_context=evidence.parent_label,note_context=evidence.table_title,classification_context=request.context,canonical_key=request.canonical_key,approved_by=request.corrected_by,approved_at=now,is_active=True,regression_example={"source_label":evidence.original_label,"canonical_key":request.canonical_key,"run_id":run.id}));correction.proposed_rule_id=rule.id
        item.status="RESOLVED";item.resolved_at=now;item.resolved_by=request.corrected_by;item.resolution=after;run.status="CORRECTION_PENDING";self.db.commit();return correction
    def _new_mapping_version(self,parent_version,reviewer,summary,now):
        existing=self.db.query(StatementMappingRuleVersion).filter_by(version=parent_version).one_or_none();n=self.db.query(StatementMappingRuleVersion).count()+1
        return self.repo.add(StatementMappingRuleVersion(version=f"{MAPPING_VERSION}.r{n}",parent_version_id=existing.id if existing else None,blueprint_version="1.0",status="ACTIVE",approved_by=reviewer,approved_at=now,change_summary=summary))
    def create_rerun(self,run_id:int,request:RerunRequest,now:datetime|None=None):
        now=now or datetime.now(timezone.utc);parent=self.repo.get_run(run_id,with_inputs=True)
        if not parent:raise ExtractionNotFound("parent run not found")
        child=self.repo.add(StatementExtractionRun(run_uid=str(uuid.uuid4()),instrument_id=parent.instrument_id,company_name=parent.company_name,scope=parent.scope,output_currency=parent.output_currency,output_unit=parent.output_unit,selected_years=parent.selected_years,status="FILES_REGISTERED",review_required=False,extraction_engine_version=ENGINE_VERSION,mapping_rule_version=request.mapping_rule_version or parent.mapping_rule_version,validation_rule_version=parent.validation_rule_version,workbook_format_version=parent.workbook_format_version,parent_run_id=parent.id,version_number=self.repo.next_version(parent.instrument_id,parent.scope),details={"rerun_requested_by":request.reviewer}))
        for i in parent.inputs:self.repo.add(StatementExtractionInput(run_id=child.id,requirement_id=i.requirement_id,requirement_group_id=i.requirement_group_id,source_id=i.source_id,raw_vault_reference=i.raw_vault_reference,original_filename=i.original_filename,safe_filename=i.safe_filename,mime_type=i.mime_type,size_bytes=i.size_bytes,checksum=i.checksum,source_url=i.source_url,local_processing_reference=i.local_processing_reference,input_metadata=i.input_metadata))
        self.repo.audit(child.id,"RERUN_CREATED",f"Rerun of {parent.id}",now,actor=request.reviewer);self.db.commit();return child
    def publish_to_block20(self,run_id:int,*,published_by:str,as_of_at:datetime):
        run=self.repo.get_run(run_id)
        if not run:raise ExtractionNotFound("run not found")
        vr=self.repo.latest_validation_run(run_id)
        if not vr or not vr.export_eligible or run.status not in {"EXPORT_READY","COMPLETED"}:raise ExportBlocked("only export-eligible approved statement versions may publish")
        rows=[];values=self.repo.normalized_values(run_id);row_by_id={r.id:r for r in self.repo.normalized_rows(run_id)}
        for value in values:
            row=row_by_id[value.row_id];rows.append({"statement_type":row.statement_type,"canonical_key":row.canonical_key,"financial_year":value.financial_year,"value":str(value.value) if value.value is not None else None,"value_status":value.value_status,"evidence_id":value.evidence_id})
        period_ids=self.block20.publish(run_id=run.id,instrument_id=run.instrument_id,scope=run.scope,years=sorted({v.financial_year for v in values}),rows=rows,as_of_at=as_of_at,published_by=published_by)
        publication=self.repo.add(StatementPublication(run_id=run.id,reporting_period_ids=period_ids,published_at=as_of_at,published_by=published_by,adapter_version="20A-to-20-v1",status="COMPLETED",details={}))
        old=self.repo.latest_current_approved(run.instrument_id,run.scope)
        if old and old.id!=run.id:old.is_current_approved=False
        run.is_current_approved=True;run.approved_at=as_of_at;run.approved_by=published_by;run.status="COMPLETED";run.completed_at=as_of_at
        for destination in ("BLOCK_21","BLOCK_22"):
            payload={"statement_run_id":run.id,"reporting_period_ids":period_ids,"scope":run.scope,"source_cutoff":as_of_at.isoformat(),"validation_status":"PASSED"}
            handoff=self.repo.add(StatementDownstreamHandoff(run_id=run.id,destination=destination,status="READY",payload=payload,created_at_business=as_of_at))
            try:handoff.payload_reference=self.jobs.enqueue(destination,payload);handoff.status="DISPATCHED"
            except RuntimeError:pass
        # future Block 22A explicit deferred handoff
        self.repo.add(StatementDownstreamHandoff(run_id=run.id,destination="BLOCK_22A",status="DEFERRED_NOT_BUILT",payload={"run_id":run.id,"artifact_ids":[a.id for a in self.repo.artifacts(run.id)],"evidence_ids":[e.id for e in self.repo.evidence(run.id)],"validation_result_ids":[v.id for v in self.repo.validation_results(run.id)]},created_at_business=as_of_at))
        self.db.commit();return publication
    def compare_runs(self,parent_run_id:int,child_run_id:int)->dict[str,Any]:
        parent=self.repo.get_run(parent_run_id);child=self.repo.get_run(child_run_id)
        if not parent or not child:raise ExtractionNotFound("comparison run not found")
        if child.parent_run_id not in {parent.id,None} and parent.parent_run_id!=child.id:
            raise ExtractionError("runs are not in the same rerun lineage")
        def value_map(run_id:int):
            rows={r.id:r for r in self.repo.normalized_rows(run_id)};out={}
            for v in self.repo.normalized_values(run_id):
                row=rows.get(v.row_id)
                if row:out[(row.statement_type,row.canonical_key,v.financial_year)]={"value":str(v.value) if v.value is not None else None,"status":v.value_status,"evidence_id":v.evidence_id}
            return out
        pvals=value_map(parent.id);cvals=value_map(child.id);changed_values=[]
        for key in sorted(set(pvals)|set(cvals)):
            if pvals.get(key)!=cvals.get(key):changed_values.append({"statement_type":key[0],"canonical_key":key[1],"financial_year":key[2],"before":pvals.get(key),"after":cvals.get(key)})
        def mapping_map(run_id:int):
            return {(e.statement_type,e.financial_year,e.original_label,e.page_number):e.canonical_key for e in self.repo.evidence(run_id)}
        pm= mapping_map(parent.id);cm=mapping_map(child.id);changed_mappings=[]
        for key in sorted(set(pm)|set(cm),key=lambda x:(str(x[0]),str(x[1]),str(x[2]),str(x[3]))):
            if pm.get(key)!=cm.get(key):changed_mappings.append({"statement_type":key[0],"financial_year":key[1],"original_label":key[2],"page_number":key[3],"before":pm.get(key),"after":cm.get(key)})
        p_open={r.item_type+":"+r.reason:r.id for r in self.repo.review_items(parent.id,status="OPEN")};c_open={r.item_type+":"+r.reason:r.id for r in self.repo.review_items(child.id,status="OPEN")}
        pv={(v.check_id,v.financial_year):(v.outcome,v.message) for v in self.repo.validation_results(parent.id)};cv={(v.check_id,v.financial_year):(v.outcome,v.message) for v in self.repo.validation_results(child.id)}
        validation_changes=[{"check_id":k[0],"financial_year":k[1],"before":pv.get(k),"after":cv.get(k)} for k in sorted(set(pv)|set(cv),key=lambda x:(x[0],str(x[1]))) if pv.get(k)!=cv.get(k)]
        return {"parent_run_id":parent.id,"child_run_id":child.id,"changed_mappings":changed_mappings,"changed_values":changed_values,"resolved_review_items":[p_open[k] for k in p_open.keys()-c_open.keys()],"new_review_items":[c_open[k] for k in c_open.keys()-p_open.keys()],"validation_changes":validation_changes}

    def artifact_path(self,artifact_id:int)->tuple[StatementExtractionArtifact,Path]:
        artifact=self.repo.get_artifact(artifact_id)
        if not artifact:raise ExtractionNotFound("artifact not found")
        if not artifact.download_available:raise ExportBlocked("artifact download is not available in its current validation state")
        path=self.artifacts.resolve(artifact.storage_reference)
        if not path.is_file():raise ExtractionNotFound("artifact storage object is unavailable")
        if artifact.checksum and sha256_file(path)!=artifact.checksum:raise ExtractionError("artifact checksum verification failed")
        return artifact,path
    def preview_payload(self,artifact_id:int):
        artifact=self.repo.get_artifact(artifact_id)
        if not artifact or not artifact.preview_available:raise ExtractionNotFound("preview unavailable")
        run=self.repo.get_run(artifact.run_id);rows=self.repo.normalized_rows(run.id);values=self.repo.normalized_values(run.id);evidence={e.id:e for e in self.repo.evidence(run.id)};by_row={}
        for v in values:by_row.setdefault(v.row_id,[]).append(v)
        sheets=[];names={"INCOME_STATEMENT":"INCOME STATEMENT","BALANCE_SHEET":"BALANCE SHEET","CASH_FLOW_STATEMENT":"CASH FLOW STATEMENT"}
        years=sorted({v.financial_year for v in values})
        for st,name in names.items():
            out=[]
            for r in [x for x in rows if x.statement_type==st]:
                cells={}
                for v in by_row.get(r.id,[]):
                    e=evidence.get(v.evidence_id);cells[f"FY{str(v.financial_year)[-2:]}"]={"raw_value":str(v.value) if v.value is not None else None,"display_value":None if v.value is None else f"₹ {v.value:,.2f}","formula":v.formula_definition or None,"status":v.value_status,"evidence_ids":[v.evidence_id] if v.evidence_id else [],"source_page":e.page_number if e else None,"review_required":v.value_status=="AMBIGUOUS_REVIEW_REQUIRED","missing":v.value_status=="MISSING_NOT_DISCLOSED"}
                out.append({"key":r.canonical_key,"label":r.display_label,"row_type":r.row_type,"value_type":r.value_type,"hierarchy_level":r.hierarchy_level,"cells":cells,"blank_after":r.blank_after})
            sheets.append({"name":name,"years":[f"FY{str(y)[-2:]}" for y in years],"rows":out})
        vr=self.repo.latest_validation_run(run.id);return {"artifact":artifact,"company_name":run.company_name,"scope":run.scope,"years":[f"FY{str(y)[-2:]}" for y in years],"validation_summary":{"critical_count":vr.critical_count if vr else 0,"error_count":vr.error_count if vr else 0,"warning_count":vr.warning_count if vr else 0,"passed_count":vr.passed_count if vr else 0,"export_eligible":vr.export_eligible if vr else False,"scope_consistent":not any(x.check_id=="G-01" and x.outcome=="FAIL" for x in self.repo.validation_results(run.id)),"balance_sheet_balances":not any(x.check_id=="BS-BALANCE" and x.outcome=="FAIL" for x in self.repo.validation_results(run.id)),"cash_flow_reconciles":not any(x.check_id=="CF-ROLL" and x.outcome=="FAIL" for x in self.repo.validation_results(run.id)),"no_unexplained_plug":not any(x.check_id=="G-06" and x.outcome=="FAIL" for x in self.repo.validation_results(run.id)),"no_material_unmapped_lines":not any(x.materiality=="MATERIAL" and x.review_status=="OPEN" for x in self.repo.unmapped_lines(run.id)),"exact_missing_conditions":[]},"sheets":sheets,"auxiliary_counts":{"sources":len(evidence),"validation_results":len(self.repo.validation_results(run.id)),"unmapped_lines":len(self.repo.unmapped_lines(run.id)),"review_items":len(self.repo.review_items(run.id)),"restatements":len(self.repo.restatements(run.id))}}
    def _model_dict(self,obj):
        return {c.name:getattr(obj,c.name) for c in obj.__table__.columns if c.name not in {"created_at","updated_at"}}
