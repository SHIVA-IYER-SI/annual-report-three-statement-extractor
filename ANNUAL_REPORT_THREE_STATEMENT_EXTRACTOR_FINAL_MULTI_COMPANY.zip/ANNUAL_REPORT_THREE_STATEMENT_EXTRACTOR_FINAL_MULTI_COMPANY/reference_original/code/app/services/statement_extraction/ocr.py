"""Controlled OCR boundary. OCR is optional and never silently assumed."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

@dataclass(frozen=True)
class OCRPageResult:
    page_number:int; text:str; confidence:float|None; engine:str; words:list[dict]

class OCRAdapter(Protocol):
    def available(self)->bool: ...
    def extract_pages(self,pdf_path:Path,pages:list[int])->list[OCRPageResult]: ...

class DisabledOCRAdapter:
    def available(self)->bool:return False
    def extract_pages(self,pdf_path:Path,pages:list[int])->list[OCRPageResult]:
        raise RuntimeError("OCR adapter is not configured")

class TesseractOCRAdapter:
    """Local adapter activated only when pytesseract/pdf2image and executable exist."""
    def available(self)->bool:
        try:
            import pytesseract
            from pdf2image import convert_from_path
            return bool(pytesseract.get_tesseract_version())
        except Exception:return False
    def extract_pages(self,pdf_path:Path,pages:list[int])->list[OCRPageResult]:
        if not self.available(): raise RuntimeError("Tesseract OCR dependencies/executable unavailable")
        import pytesseract
        from pdf2image import convert_from_path
        out=[]
        for page_no in pages:
            images=convert_from_path(str(pdf_path),first_page=page_no,last_page=page_no,dpi=300)
            data=pytesseract.image_to_data(images[0],output_type=pytesseract.Output.DICT)
            words=[]; conf=[]
            for i,text in enumerate(data["text"]):
                if not text.strip():continue
                c=float(data["conf"][i]) if str(data["conf"][i])!="-1" else 0
                conf.append(c); words.append({"text":text,"confidence":c,"left":data["left"][i],"top":data["top"][i],"width":data["width"][i],"height":data["height"][i]})
            out.append(OCRPageResult(page_no," ".join(w["text"] for w in words),(sum(conf)/len(conf)/100 if conf else None),"tesseract",words))
        return out
