"""Native PDF extraction baseline using pdfplumber when installed.

It extracts page text/words, scans for image-dominant pages, obtains table
cells, and emits auditable row candidates with page coordinates. It does not
claim universal PDF-table accuracy; uncertain rows are review candidates.
"""
from __future__ import annotations
from dataclasses import dataclass,field
from pathlib import Path
from typing import Any
from .detection import detect_statement_pages
from .parsing import detect_unit, extract_year_headers, parse_number

class PDFDependencyMissing(RuntimeError): pass

@dataclass
class PDFRowCandidate:
    statement_type:str; scope:str; page_number:int; table_index:int; row_index:int; original_label:str; values:dict[int,str|None]
    unit:str|None; bbox:dict[str,float]=field(default_factory=dict); raw_cells:list[Any]=field(default_factory=list); confidence:float=0.7

@dataclass
class PDFExtractionResult:
    page_texts:list[str]; scanned_pages:list[int]; statement_detections:list[Any]; rows:list[PDFRowCandidate]; page_metadata:list[dict[str,Any]]

class NativePDFExtractor:
    def __init__(self,min_native_chars:int=80): self.min_native_chars=min_native_chars
    def extract(self,path:Path)->PDFExtractionResult:
        try: import pdfplumber
        except ImportError as exc: raise PDFDependencyMissing("pdfplumber is required for native PDF extraction") from exc
        page_texts=[]; scanned=[]; page_meta=[]; tables_by_page=[]
        with pdfplumber.open(path) as pdf:
            for page_no,page in enumerate(pdf.pages,start=1):
                text=page.extract_text(x_tolerance=2,y_tolerance=3) or ""; page_texts.append(text)
                words=page.extract_words(use_text_flow=True,keep_blank_chars=False)
                image_count=len(page.images or [])
                if len(text.strip())<self.min_native_chars and image_count>0: scanned.append(page_no)
                table_settings={"vertical_strategy":"lines","horizontal_strategy":"lines","snap_tolerance":4,"join_tolerance":4,"intersection_tolerance":6}
                tables=page.extract_tables(table_settings=table_settings) or []
                if not tables:
                    tables=page.extract_tables({"vertical_strategy":"text","horizontal_strategy":"text","text_tolerance":3,"intersection_tolerance":8}) or []
                tables_by_page.append(tables)
                page_meta.append({"page_number":page_no,"width":page.width,"height":page.height,"text_characters":len(text),"word_count":len(words),"image_count":image_count,"table_count":len(tables)})
        detections=detect_statement_pages(page_texts)
        detection_by_page={d.page_number:d for d in detections}
        rows=[]
        active=None
        for page_idx,tables in enumerate(tables_by_page,start=1):
            if page_idx in detection_by_page: active=detection_by_page[page_idx]
            if not active: continue
            page_unit=detect_unit(page_texts[page_idx-1])
            for table_idx,table in enumerate(tables):
                years=[]
                for header in table[:4]:
                    years=extract_year_headers(header)
                    if years: break
                if not years: continue
                for row_idx,cells in enumerate(table):
                    clean=["" if c is None else str(c).strip() for c in cells]
                    if not any(clean): continue
                    label=next((c for c in clean if c and parse_number(c).value is None and not any(str(y) in c for y in years)),"")
                    if not label or len(label)>500: continue
                    numeric=[c for c in clean if parse_number(c).value is not None or c.strip() in {"-","–","—","nil","Nil"}]
                    if not numeric: continue
                    values={year:(numeric[-len(years)+i] if len(numeric)>=len(years) else None) for i,year in enumerate(years)}
                    confidence=0.82 if len(numeric)>=len(years) else 0.55
                    rows.append(PDFRowCandidate(active.statement_type,active.scope,page_idx,table_idx,row_idx,label,values,page_unit,{},clean,confidence))
        return PDFExtractionResult(page_texts,scanned,detections,rows,page_meta)
