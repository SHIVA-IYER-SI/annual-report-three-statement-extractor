"""Local CLI using the same extraction services as the API.

Example:
python -m app.services.statement_extraction.cli --company "Tata Consultancy Services Limited" --instrument-id 1 --scope consolidated --input annual_report.pdf --output ./artifacts
"""
from __future__ import annotations
import argparse,json,sys,tempfile
from pathlib import Path
from app.models.statement_extraction import AccountingScope
from app.schemas.statement_extraction import CreateExtractionRunRequest,ExtractionInputRef
from .security import safe_filename,sha256_file,validate_input_file

def parser():
    p=argparse.ArgumentParser(prog="extract-three-statements")
    p.add_argument("--company",required=True);p.add_argument("--instrument-id",type=int,required=True)
    p.add_argument("--scope",choices=["consolidated","standalone"],default="consolidated")
    p.add_argument("--input",type=Path,action="append",required=True);p.add_argument("--output",type=Path,required=True)
    p.add_argument("--year",type=int,action="append",default=[]);p.add_argument("--mapping-rule-version");p.add_argument("--review-mode-export",action="store_true")
    p.add_argument("--database-url",help="Optional SQLAlchemy URL; otherwise KUBERPATH_DATABASE_URL is used")
    return p

def main(argv=None):
    args=parser().parse_args(argv)
    issues={str(p):validate_input_file(p) for p in args.input};issues={k:v for k,v in issues.items() if v}
    if issues:print(json.dumps({"status":"FAILED","issues":issues},indent=2));return 2
    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import Session
        import os
        from .engine import StatementExtractionEngine
        url=args.database_url or os.getenv("KUBERPATH_DATABASE_URL")
        if not url:raise RuntimeError("KUBERPATH_DATABASE_URL or --database-url is required")
        engine=create_engine(url)
        with Session(engine) as db:
            request=CreateExtractionRunRequest(instrument_id=args.instrument_id,company_name=args.company,scope=AccountingScope(args.scope.upper()),selected_years=args.year,inputs=[ExtractionInputRef(original_filename=p.name,checksum=sha256_file(p),mime_type="application/pdf" if p.suffix.lower()==".pdf" else "application/xml",size_bytes=p.stat().st_size,local_processing_reference=str(p.resolve())) for p in args.input])
            service=StatementExtractionEngine(db)
            run=service.create_run(request);completed=service.run_sync(run.id)
            arts=service.repo.artifacts(run.id)
            output={"run_id":run.id,"status":completed.status,"review_required":completed.review_required,"artifacts":[{"id":a.id,"filename":a.filename,"type":a.artifact_type,"download_available":a.download_available} for a in arts]}
            print(json.dumps(output,indent=2));return 3 if completed.review_required and not args.review_mode_export else 0
    except Exception as exc:
        print(json.dumps({"status":"FAILED","error":type(exc).__name__,"message":str(exc)},indent=2));return 1
if __name__=="__main__":raise SystemExit(main())
