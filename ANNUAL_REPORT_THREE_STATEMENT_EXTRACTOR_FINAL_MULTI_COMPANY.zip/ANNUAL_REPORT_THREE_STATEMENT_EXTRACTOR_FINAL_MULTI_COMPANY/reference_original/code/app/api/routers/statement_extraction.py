"""Internal FastAPI routes for Block 20A extraction, review and artifacts."""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,Query,UploadFile,File,Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.repositories.statement_extraction import StatementExtractionRepository
from app.schemas.statement_extraction import *
from app.services.statement_extraction.engine import DependencyMissing,ExportBlocked,ExtractionError,ExtractionNotFound,StatementExtractionEngine
from app.services.statement_extraction.security import safe_filename,validate_input_file,sha256_file

router=APIRouter(prefix="/statement-extraction",tags=["statement-extraction"])

def _engine(db:Session)->StatementExtractionEngine:return StatementExtractionEngine(db)
def _error(exc:Exception)->HTTPException:
    if isinstance(exc,ExtractionNotFound):return HTTPException(404,str(exc))
    if isinstance(exc,ExportBlocked):return HTTPException(409,str(exc))
    if isinstance(exc,DependencyMissing):return HTTPException(503,str(exc))
    if isinstance(exc,(ExtractionError,ValueError)):return HTTPException(422,str(exc))
    return HTTPException(500,"statement extraction operation failed")

@router.post("/runs",response_model=ExtractionRunSummaryOut)
def create_run(request:CreateExtractionRunRequest,db:Session=Depends(get_db)):
    try:return _engine(db).create_run(request)
    except Exception as exc:raise _error(exc) from exc

@router.get("/runs",response_model=ExtractionRunPage)
def list_runs(instrument_id:int|None=None,status:str|None=None,limit:int=Query(50,ge=1,le=200),offset:int=Query(0,ge=0),db:Session=Depends(get_db)):
    rows,total=StatementExtractionRepository(db).list_runs(instrument_id=instrument_id,status=status,limit=limit,offset=offset)
    return ExtractionRunPage(items=rows,total=total,limit=limit,offset=offset)

@router.get("/runs/{run_id}",response_model=ExtractionRunSummaryOut)
def run_detail(run_id:int,db:Session=Depends(get_db)):
    row=StatementExtractionRepository(db).get_run(run_id)
    if not row:raise HTTPException(404,"run not found")
    return row

@router.post("/runs/{run_id}/start",response_model=ExtractionRunSummaryOut)
def start_run(run_id:int,db:Session=Depends(get_db)):
    try:return _engine(db).run_sync(run_id)
    except Exception as exc:raise _error(exc) from exc

@router.post("/runs/{run_id}/files",response_model=ExtractionInputOut)
async def upload_run_file(run_id:int,file:UploadFile=File(...),requirement_id:int|None=Form(None),requirement_group_id:int|None=Form(None),source_id:int|None=Form(None),db:Session=Depends(get_db)):
    """Local intake boundary. Production binds this to the existing Raw Vault."""
    engine=_engine(db);run=engine.repo.get_run(run_id)
    if not run:raise HTTPException(404,"run not found")
    import tempfile
    target=Path(tempfile.mkdtemp(prefix="kuberpath_upload_"))/safe_filename(file.filename or "document")
    total=0
    with target.open("wb") as fh:
        while chunk:=await file.read(1024*1024):
            total+=len(chunk)
            if total>250*1024*1024:target.unlink(missing_ok=True);raise HTTPException(413,"file exceeds 250 MB limit")
            fh.write(chunk)
    issues=validate_input_file(target,file.content_type)
    if issues:target.unlink(missing_ok=True);raise HTTPException(422,{"issues":issues})
    try:
        stored=engine.raw_vault.store(target,filename=file.filename or target.name,mime_type=file.content_type,metadata={"run_id":run_id})
        row=engine.repo.add(__import__("app.models.statement_extraction",fromlist=["StatementExtractionInput"]).StatementExtractionInput(run_id=run_id,requirement_id=requirement_id,requirement_group_id=requirement_group_id,source_id=source_id,raw_vault_reference=stored.reference,original_filename=file.filename or target.name,safe_filename=safe_filename(file.filename or target.name),mime_type=file.content_type,size_bytes=stored.size_bytes,checksum=stored.checksum,input_metadata={"upload_intake":"block20a"}))
        run.status="FILES_REGISTERED";db.commit();return row
    finally:
        target.unlink(missing_ok=True)
        try:target.parent.rmdir()
        except OSError:pass

@router.get("/runs/{run_id}/evidence",response_model=list[SourceEvidenceOut])
def evidence(run_id:int,selected:bool|None=None,statement_type:str|None=None,db:Session=Depends(get_db)):
    return StatementExtractionRepository(db).evidence(run_id,selected=selected,statement_type=statement_type)

@router.get("/runs/{run_id}/validations",response_model=list[ValidationResultOut])
def validations(run_id:int,db:Session=Depends(get_db)):return StatementExtractionRepository(db).validation_results(run_id)

@router.get("/runs/{run_id}/review-items",response_model=list[ReviewItemOut])
def review_items(run_id:int,status:str|None=None,db:Session=Depends(get_db)):return StatementExtractionRepository(db).review_items(run_id,status=status)

@router.post("/runs/{run_id}/review-items/{review_item_id}/resolve",response_model=CorrectionOut)
def resolve_review(run_id:int,review_item_id:int,request:CorrectionRequest,db:Session=Depends(get_db)):
    try:return _engine(db).apply_correction(run_id,review_item_id,request)
    except Exception as exc:raise _error(exc) from exc

@router.post("/runs/{run_id}/rerun",response_model=ExtractionRunSummaryOut)
def rerun(run_id:int,request:RerunRequest,db:Session=Depends(get_db)):
    try:return _engine(db).create_rerun(run_id,request)
    except Exception as exc:raise _error(exc) from exc

@router.post("/runs/{run_id}/publish",response_model=PublicationOut)
def publish(run_id:int,request:PublishRunRequest,db:Session=Depends(get_db)):
    try:
        row=_engine(db).publish_to_block20(run_id,published_by=request.published_by,as_of_at=request.as_of_at)
        handoffs=StatementExtractionRepository(db)
        return PublicationOut(run_id=run_id,status=row.status,reporting_period_ids=row.reporting_period_ids)
    except Exception as exc:raise _error(exc) from exc


@router.get("/runs/{parent_run_id}/compare/{child_run_id}",response_model=RunComparisonOut)
def compare_runs(parent_run_id:int,child_run_id:int,db:Session=Depends(get_db)):
    try:return _engine(db).compare_runs(parent_run_id,child_run_id)
    except Exception as exc:raise _error(exc) from exc

@router.get("/runs/{run_id}/unmapped-lines")
def unmapped_lines(run_id:int,db:Session=Depends(get_db)):
    return StatementExtractionRepository(db).unmapped_lines(run_id)

@router.get("/runs/{run_id}/mapping-candidates",response_model=list[MappingCandidateOut])
def mapping_candidates(run_id:int,evidence_id:int|None=None,db:Session=Depends(get_db)):
    return StatementExtractionRepository(db).mapping_candidates(run_id,evidence_id)

@router.get("/runs/{run_id}/artifacts",response_model=list[ArtifactOut])
def artifacts(run_id:int,db:Session=Depends(get_db)):return StatementExtractionRepository(db).artifacts(run_id)

@router.get("/artifacts/{artifact_id}/preview",response_model=ArtifactPreviewOut)
def preview(artifact_id:int,db:Session=Depends(get_db)):
    try:return _engine(db).preview_payload(artifact_id)
    except Exception as exc:raise _error(exc) from exc

@router.get("/artifacts/{artifact_id}/download")
def download(artifact_id:int,db:Session=Depends(get_db)):
    try:
        artifact,path=_engine(db).artifact_path(artifact_id)
        return FileResponse(path,media_type=artifact.mime_type,filename=artifact.filename,headers={"X-Kuberpath-Artifact-ID":str(artifact.id)})
    except Exception as exc:raise _error(exc) from exc
