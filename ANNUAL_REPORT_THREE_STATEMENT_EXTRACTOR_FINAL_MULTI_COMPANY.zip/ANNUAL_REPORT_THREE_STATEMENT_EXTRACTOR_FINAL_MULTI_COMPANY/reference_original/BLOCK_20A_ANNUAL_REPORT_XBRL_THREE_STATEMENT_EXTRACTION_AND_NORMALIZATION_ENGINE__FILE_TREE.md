# Block 20A File Tree

All paths inside `code/` are repository-relative integration paths. No dependency ZIP, original blueprint ZIP, TCS document, environment file, node_modules, virtual environment, cache or build output is included.

```text
BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE/
├── code/
│   ├── alembic/
│   │   └── versions/
│   │       └── 0015_create_statement_extraction_engine.py
│   ├── app/
│   │   ├── api/
│   │   │   └── routers/
│   │   │       └── statement_extraction.py
│   │   ├── models/
│   │   │   └── statement_extraction.py
│   │   ├── repositories/
│   │   │   └── statement_extraction.py
│   │   ├── schemas/
│   │   │   └── statement_extraction.py
│   │   └── services/
│   │       └── statement_extraction/
│   │           ├── resources/
│   │           │   ├── balance_sheet_line_item_universe.json
│   │           │   ├── balance_sheet_validation_checks.json
│   │           │   ├── blueprint_resource_manifest.json
│   │           │   ├── cash_flow_line_item_universe.json
│   │           │   ├── cash_flow_validation_checks.json
│   │           │   ├── income_statement_line_item_universe.json
│   │           │   ├── income_statement_validation_checks.json
│   │           │   ├── input_payload_schema.json
│   │           │   ├── output_contract.json
│   │           │   ├── source_record_schema.json
│   │           │   └── style_config.json
│   │           ├── __init__.py
│   │           ├── artifacts.py
│   │           ├── assembly.py
│   │           ├── cli.py
│   │           ├── detection.py
│   │           ├── engine.py
│   │           ├── mapping.py
│   │           ├── ocr.py
│   │           ├── parsing.py
│   │           ├── pdf_native.py
│   │           ├── ports.py
│   │           ├── resources.py
│   │           ├── restatements.py
│   │           ├── security.py
│   │           ├── validation.py
│   │           ├── workbook.py
│   │           └── xbrl.py
│   ├── frontend/
│   │   └── src/
│   │       ├── app/
│   │       │   └── (terminal)/
│   │       │       └── fundamentals/
│   │       │           └── extraction/
│   │       │               └── page.tsx
│   │       ├── features/
│   │       │   └── statement-extraction/
│   │       │       ├── artifact-card.tsx
│   │       │       ├── extraction-form.tsx
│   │       │       ├── extraction-page.tsx
│   │       │       ├── review-queue.tsx
│   │       │       ├── run-history.tsx
│   │       │       ├── statement-extraction.module.css
│   │       │       ├── use-statement-extraction.ts
│   │       │       └── workbook-preview-drawer.tsx
│   │       ├── lib/
│   │       │   ├── api/
│   │       │   │   ├── modules/
│   │       │   │   │   └── statement-extraction.ts
│   │       │   │   └── index.ts
│   │       │   ├── config/
│   │       │   │   ├── feature-flags.ts
│   │       │   │   └── routes.ts
│   │       │   └── query/
│   │       │       └── keys.ts
│   │       └── types/
│   │           └── statement-extraction.ts
│   ├── requirements/
│   │   └── block20a.txt
│   └── tests/
│       └── statement_extraction/
│           ├── test_artifacts.py
│           ├── test_blueprint_integrity.py
│           ├── test_mapping_and_assembly.py
│           ├── test_numeric_and_units.py
│           ├── test_restatements.py
│           ├── test_security.py
│           ├── test_validation.py
│           └── test_workbook_contract.py
├── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__FILE_TREE.md
├── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__INTEGRATION_NOTES.md
├── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__NOTE.md
├── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__PLAN.md
├── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__TCS_RUNBOOK.md
└── BLOCK_20A_ANNUAL_REPORT_XBRL_THREE_STATEMENT_EXTRACTION_AND_NORMALIZATION_ENGINE__TODOS.md
```

## Important runtime groups

- `app/services/statement_extraction/resources/`: verified blueprint resources and checksum manifest.
- `app/services/statement_extraction/`: extraction, mapping, assembly, validation, review, artifact and integration logic.
- `app/models`, `app/schemas`, `app/repositories`, `app/api/routers`: backend integration surface.
- `frontend/src/features/statement-extraction/`: functional extraction/review/artifact interface.
- `alembic/versions/0015_create_statement_extraction_engine.py`: Block 20A migration.
- `tests/statement_extraction/`: focused deterministic and workbook-contract tests.
