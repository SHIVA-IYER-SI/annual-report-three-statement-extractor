# Block 20A Integration Notes

## Dependencies inspected

Actual extracted packages inspected:

- Block 20: `app/models/fundamentals.py`, `app/schemas/fundamentals.py`, migration `0006`.
- Block 21: ratio output and reporting-period dependency patterns.
- Block 22 partial: red-flag and evidence boundaries.
- Block 23: event package conventions and migration patterns.
- Blocks 28–29: evidence, artifact, immutable-run and handoff patterns.
- Block 30: `frontend/` Next.js App Router foundation, shared UI, API client, status/theme/query conventions.
- Block 30A: requirement models/services/API/frontend and migration `0014`.

Complete Block 2, 5, 6 and 7 ZIPs were not present in the active runtime. Their concrete classes were therefore not invented. Narrow ports are provided for the raw vault, Block 20 publication, Block 30A callback and downstream jobs. Bind these ports to the real repository implementations during integration.

## Paths created

Backend:

- `app/models/statement_extraction.py`
- `app/schemas/statement_extraction.py`
- `app/repositories/statement_extraction.py`
- `app/services/statement_extraction/*`
- `app/api/routers/statement_extraction.py`
- `alembic/versions/0015_create_statement_extraction_engine.py`
- `requirements/block20a.txt`

Frontend:

- `frontend/src/app/(terminal)/fundamentals/extraction/page.tsx`
- `frontend/src/features/statement-extraction/*`
- `frontend/src/lib/api/modules/statement-extraction.ts`
- `frontend/src/types/statement-extraction.ts`
- controlled edits to route, flag, API export and query-key configuration.

Tests:

- `tests/statement_extraction/*`

## Reused conventions

- `Base`/`TimestampMixin` from `app.db.base`.
- instrument FK `instruments.id`.
- source FK `source_registry.id`.
- Block 30A FKs `document_requirement_instances.id` and `document_requirement_groups.id`.
- SQLAlchemy 2 `Mapped`/`mapped_column` style.
- string status vocabularies rather than new PostgreSQL enums.
- FastAPI session dependency via `app.core.db.get_db`.
- Block 30 App Router, TanStack Query, shared UI components and centralized API client.

## Migration

- Latest inspected migration: Block 30A `0014`, revising `0013`.
- Block 20A migration: `0015`, `down_revision = "0014"`.
- Migration was not executed.
- Confirm `alembic heads` after merging. Rebase revision numbering if the local repository has advanced.

## Model registration

Import `app.models.statement_extraction` through the existing model registry so its tables join the shared metadata. Do not create another `Base`.

## Router wiring

Include `app.api.routers.statement_extraction.router` under the internal API router. Apply the same authentication/authorization dependency used by other internal Kuberpath routers; this block does not invent an auth contract.

## Storage and upload wiring

`LocalRawVaultPort` and `FileSystemArtifactStorage` exist only for local testing. In the integrated application:

- bind `RawVaultPort` to Block 6/7 storage and metadata;
- bind `ArtifactStorage` to shared object/file storage;
- preserve checksum verification;
- keep storage references opaque;
- do not retain a second permanent document store.

## Block 20 publication boundary

Block 20 remains the statement of record through `ReportingPeriod`, its three statement tables and `StatementLineItem`.

The concrete `Block20PublisherPort` should:

1. create one annual period/revision per instrument, period end and selected basis;
2. set `as_of_available_at` from source publication/availability, not ingestion convenience;
3. preserve source/raw references and Block 20A run/evidence IDs;
4. map named high-signal keys to Block 20 canonical columns;
5. publish other approved keys to `StatementLineItem`;
6. mark formula-derived values as derived;
7. preserve older revisions;
8. accept only export-eligible approved runs.

Block 21 and Block 22 handoffs carry published period IDs, scope, years, source cutoff and versions. Their calculations are not duplicated here.

## Block 22A deferred handoff

A `DEFERRED_NOT_BUILT` payload retains annual-report inputs, evidence/page/note references, extraction confidence, mappings, validation, review, unmapped lines and approved artifact IDs. It contains no fabricated Green/Amber/Red analysis.

## Block 30A callback

Inputs retain `requirement_id`/`requirement_group_id`. Block 20A reports:

- `REVIEW_REQUIRED` while extraction or validation is unresolved;
- `VALIDATED` only when export criteria pass;
- exact failing conditions;
- revision/run lineage.

Upload alone never completes a Block 30A requirement.

## Frontend integration

Route: `/fundamentals/extraction`.

Merge, do not blindly overwrite, the supplied edits to:

- `frontend/src/lib/config/routes.ts`
- `frontend/src/lib/config/feature-flags.ts`
- `frontend/src/lib/api/index.ts`
- `frontend/src/lib/query/keys.ts`

The page supports multi-file upload, run execution/status, source-backed review corrections, immutable child reruns, artifacts, workbook preview and history. `CORRECTION_PENDING` creates a child rerun; it does not mutate the original run.

## Blueprint resources

Runtime resources are under `app/services/statement_extraction/resources/`. `blueprint_resource_manifest.json` records source path, bytes and SHA-256. `verify_runtime_resources()` fails closed on drift.

## PDF extraction

The native baseline uses `pdfplumber` for page text/words, scanned-page signals, statement title/page-local scope detection, line/text table extraction, year headers and raw row preservation.

Known limitation: complex borderless, rotated, nested and multi-page note tables will require real-document correction work. This is disclosed rather than hidden.

## OCR boundary

- OCR is disabled by default.
- Optional Tesseract adapter requires both Python dependency and local executable.
- scanned pages without OCR create blocking review items;
- low-confidence material OCR blocks final export;
- OCR was not executed here.

## XBRL boundary

The parser preserves contexts, dates, dimensions, units, decimals, scale, nil state, QName/concept, raw and numeric values. Annual-duration facts may enter the annual model; interim durations stay stored but excluded. No one-concept/one-key global assumption is made.

## Validation

All 58 blueprint validation definitions are loaded and versioned. Global/critical reconciliations execute when canonical inputs exist. Missing-input declarative checks remain `NOT_RUN`, never false `PASS`. Material unmapped lines, blocking reviews, scope/unit ambiguity, duplicate ownership, residuals and failed reconciliations block final export.

## Artifact and download behavior

- review runs create a `_REVIEW_REQUIRED.xlsx` workbook and audit pack;
- final workbook exists only when export eligible;
- workbook has exactly three sheets;
- preview uses structured rows rather than browser-side formula execution;
- download verifies state, resolves opaque storage and verifies checksum;
- internal paths are never exposed.

## Security

- 250 MB HTTP intake limit;
- extension/MIME/checksum validation;
- safe filename/path containment;
- no macros or external URL fetching;
- no credentials;
- source text beginning `=`, `+`, `-`, `@` is escaped;
- only the controlled compiler creates formulas.

## Executed evidence

- `python -m compileall -q code`: completed.
- `PYTHONPATH=code pytest -q code/tests/statement_extraction`: 19 passed.

Not executed: live DB migration, TCS extraction, OCR, backend/frontend startup, real Block 20/30A integration or browser download.

## Fable review priorities

1. blueprint resource integrity and exact format;
2. migration/FK compatibility;
3. multi-page PDF tables and scope separation;
4. annual/interim and XBRL context selection;
5. unit/tolerance and missing-versus-zero;
6. ambiguity/mapping thresholds;
7. dynamic rows, aggregates and duplicate economics;
8. canonical-key formulas and workbook formatting;
9. execution coverage of all blueprint checks;
10. restatements and immutable evidence;
11. correction-rule scope/versioning;
12. Block 20 publication and Block 30A callback;
13. artifact storage/preview/download authorization;
14. formula injection and file security;
15. TCS correction loop/regression fixtures;
16. frontend correction and comparison UX;
17. duplicate storage or overengineering.
