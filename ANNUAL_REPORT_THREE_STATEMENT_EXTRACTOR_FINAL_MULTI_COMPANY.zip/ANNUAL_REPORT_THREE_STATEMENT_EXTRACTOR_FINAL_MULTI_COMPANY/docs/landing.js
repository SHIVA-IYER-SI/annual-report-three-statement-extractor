(() => {
  "use strict";

  const config = window.EXTRACTOR_CONFIG || {};
  const button = document.getElementById("wakeButton");
  const buttonText = button.querySelector(".buttonText");
  const statusMessage = document.getElementById("statusMessage");
  const elapsedTime = document.getElementById("elapsedTime");
  const progress = document.getElementById("wakeProgress");
  const manualLink = document.getElementById("manualLink");
  const setupNotice = document.getElementById("setupNotice");
  const rotatingQuote = document.getElementById("rotatingQuote");

  const quotes = [
    "find the depreciation note hiding on page 247.",
    "politely remind EBITDA that it is not cash flow.",
    "separate actual disclosures from management poetry.",
    "teach ten annual reports to agree on one row label.",
    "ask the balance sheet where the missing zero went.",
    "turn footnotes into something Excel can understand."
  ];

  const wakeMessages = [
    "Waking the accountants…",
    "Looking for the depreciation note…",
    "Convincing EBITDA it is not cash flow…",
    "Checking whether the footnotes have alibis…",
    "Teaching annual reports to speak Excel…",
    "Almost there—numbers are stretching."
  ];

  let quoteIndex = 0;
  setInterval(() => {
    quoteIndex = (quoteIndex + 1) % quotes.length;
    rotatingQuote.style.animation = "none";
    void rotatingQuote.offsetWidth;
    rotatingQuote.textContent = quotes[quoteIndex];
    rotatingQuote.style.animation = "quoteIn .45s ease";
  }, 4200);

  function normalizedBackendUrl() {
    return String(config.backendUrl || "").trim().replace(/\/+$/, "");
  }

  function hasPlaceholder(url) {
    return !url || url.includes("REPLACE-WITH-YOUR-RENDER-URL");
  }

  function setFailed(message) {
    button.disabled = false;
    buttonText.textContent = "Try Waking It Again";
    progress.classList.remove("indeterminate");
    progress.style.width = "100%";
    progress.style.background = "#b64040";
    statusMessage.textContent = message;
    manualLink.classList.remove("hidden");
  }

  async function wakeBackend() {
    const backendUrl = normalizedBackendUrl();
    if (hasPlaceholder(backendUrl)) {
      setupNotice.classList.remove("hidden");
      statusMessage.textContent = "The landing page needs your Render URL before it can wake Python.";
      return;
    }

    setupNotice.classList.add("hidden");
    manualLink.href = backendUrl;
    manualLink.classList.add("hidden");
    button.disabled = true;
    button.classList.remove("awake");
    buttonText.textContent = "Waking Python…";
    progress.style.background = "";
    progress.style.width = "35%";
    progress.classList.add("indeterminate");

    const startedAt = Date.now();
    const maxWakeMs = Number(config.maxWakeSeconds || 120) * 1000;
    const interval = Number(config.pollIntervalMs || 3000);
    let messageIndex = 0;

    while (Date.now() - startedAt < maxWakeMs) {
      const elapsed = Math.floor((Date.now() - startedAt) / 1000);
      elapsedTime.textContent = `${elapsed}s`;
      statusMessage.textContent = wakeMessages[messageIndex % wakeMessages.length];
      messageIndex += 1;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 12000);
        const response = await fetch(`${backendUrl}/api/health?wake=${Date.now()}`, {
          method: "GET",
          mode: "cors",
          cache: "no-store",
          signal: controller.signal
        });
        clearTimeout(timeout);

        if (response.ok) {
          const payload = await response.json().catch(() => ({}));
          if (payload.status === "ok") {
            progress.classList.remove("indeterminate");
            progress.style.width = "100%";
            button.classList.add("awake");
            button.disabled = false;
            buttonText.textContent = "Numbers Awake — Enter";
            statusMessage.textContent = "Python is awake. Opening the extractor…";
            elapsedTime.textContent = `${elapsed}s`;
            setTimeout(() => window.location.assign(`${backendUrl}/?from=wake-the-numbers`), 850);
            return;
          }
        }
      } catch (_) {
        // A sleeping Render service commonly fails or times out while it starts.
      }

      await new Promise((resolve) => setTimeout(resolve, interval));
    }

    setFailed("Python did not answer within two minutes. Try again or open the backend directly.");
  }

  button.addEventListener("click", () => {
    if (button.classList.contains("awake")) {
      window.location.assign(normalizedBackendUrl());
      return;
    }
    wakeBackend();
  });

  if (hasPlaceholder(normalizedBackendUrl())) {
    setupNotice.classList.remove("hidden");
  }
})();
