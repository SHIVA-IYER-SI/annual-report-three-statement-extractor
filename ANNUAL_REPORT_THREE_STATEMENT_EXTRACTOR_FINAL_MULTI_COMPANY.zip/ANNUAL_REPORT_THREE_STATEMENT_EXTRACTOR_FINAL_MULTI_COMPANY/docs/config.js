/*
  After Render creates your backend URL, replace the placeholder below.
  Example: https://annual-report-three-statement-extractor.onrender.com
*/
window.EXTRACTOR_CONFIG = {
  backendUrl: "https://REPLACE-WITH-YOUR-RENDER-URL.onrender.com",
  maxWakeSeconds: 120,
  pollIntervalMs: 3000
};
